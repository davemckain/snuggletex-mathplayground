/* $Id: SimpleToken.java 210 2008-08-07 20:39:09Z davemckain $
 *
 * Copyright 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.snuggletex.tokens;

import uk.ac.ed.ph.snuggletex.definitions.LaTeXMode;
import uk.ac.ed.ph.snuggletex.definitions.TextFlowContext;
import uk.ac.ed.ph.snuggletex.internal.FrozenSlice;
import uk.ac.ed.ph.snuggletex.semantics.Interpretation;

/**
 * Represents a "simple" LaTeX token. See {@link TokenType} for
 * the sorts of things this covers.
 * 
 * @see TokenType
 * 
 * @author  David McKain
 * @version $Revision: 210 $
 */
public final class SimpleToken extends FlowToken {
    
    public SimpleToken(final FrozenSlice slice, final TokenType tokenType,
            final LaTeXMode latexMode, final TextFlowContext context) {
        super(slice, tokenType, latexMode, context);
    }

    public SimpleToken(final FrozenSlice slice, final TokenType tokenType, final LaTeXMode latexMode,
            final Interpretation interpretation, final TextFlowContext context) {
        super(slice, tokenType, latexMode, interpretation, context);
    }
}
