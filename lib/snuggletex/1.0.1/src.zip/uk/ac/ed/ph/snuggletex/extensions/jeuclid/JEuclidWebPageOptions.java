/* $Id: JEuclidWebPageOptions.java 224 2009-01-05 15:34:19Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.snuggletex.extensions.jeuclid;

import uk.ac.ed.ph.snuggletex.internal.AbstractWebPageOptions;

/**
 * Options Object for {@link JEuclidWebPageBuilder}.
 * 
 * @author  David McKain
 * @version $Revision: 224 $
 */
public final class JEuclidWebPageOptions extends AbstractWebPageOptions {
    
    /** Callback to use when saving out any images produced by the process. */
    private MathMLImageSavingCallback imageSavingCallback;
    
    public JEuclidWebPageOptions() {
        super();
        this.imageSavingCallback = null;
    }
    
    public MathMLImageSavingCallback getImageSavingCallback() {
        return imageSavingCallback;
    }

    public void setImageSavingCallback(MathMLImageSavingCallback callback) {
        this.imageSavingCallback = callback;
    }
}
