/* $Id: SimpleMathOperatorInterpretation.java 224 2009-01-05 15:34:19Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.snuggletex.semantics;

import uk.ac.ed.ph.commons.util.ObjectUtilities;

/**
 * Represents a generic Mathematical operator.
 * 
 * @see MathBracketOperatorInterpretation
 * @see NottableMathOperatorInterpretation
 * 
 * @author  David McKain
 * @version $Revision: 224 $
 */
public final class SimpleMathOperatorInterpretation implements MathOperatorInterpretation {
    
    private final MathMLOperator operator;
    
    public SimpleMathOperatorInterpretation(final MathMLOperator operator) {
        this.operator = operator;
    }
    
    public MathMLOperator getOperator() {
        return operator;
    }
    
    public InterpretationType getType() {
        return InterpretationType.MATH_OPERATOR;
    }
    
    @Override
    public String toString() {
        return ObjectUtilities.beanToString(this);
    }
}
