/* $Id: EnvironmentToken.java 224 2009-01-05 15:34:19Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.snuggletex.tokens;

import uk.ac.ed.ph.commons.util.DumpMode;
import uk.ac.ed.ph.commons.util.ObjectDumperOptions;
import uk.ac.ed.ph.snuggletex.definitions.BuiltinEnvironment;
import uk.ac.ed.ph.snuggletex.definitions.LaTeXMode;
import uk.ac.ed.ph.snuggletex.internal.FrozenSlice;

/**
 * Represents a {@link BuiltinEnvironment}.
 * 
 * @author  David McKain
 * @version $Revision: 224 $
 */
public final class EnvironmentToken extends FlowToken {
    
    private final BuiltinEnvironment environment;
    private final ArgumentContainerToken optionalArgument;
    private final ArgumentContainerToken[] arguments;
    private final ArgumentContainerToken content;
    
    public EnvironmentToken(final FrozenSlice slice, final LaTeXMode latexMode,
            final BuiltinEnvironment environment, final ArgumentContainerToken content) {
        this(slice, latexMode, environment, null, ArgumentContainerToken.EMPTY_ARRAY, content);
    }
    
    public EnvironmentToken(final FrozenSlice slice, final LaTeXMode latexMode,
            final BuiltinEnvironment environment, final ArgumentContainerToken optionalArgument,
            final ArgumentContainerToken[] arguments, final ArgumentContainerToken content) {
        super(slice, TokenType.ENVIRONMENT, latexMode, environment.getInterpretation(), environment.getTextFlowContext());
        this.environment = environment;
        this.optionalArgument = optionalArgument;
        this.arguments = arguments;
        this.content = content;
    }

    public BuiltinEnvironment getEnvironment() {
        return environment;
    }
    
    @ObjectDumperOptions(DumpMode.DEEP)
    public ArgumentContainerToken getOptionalArgument() {
        return optionalArgument;
    }
    
    @ObjectDumperOptions(DumpMode.DEEP)
    public ArgumentContainerToken[] getArguments() {
        return arguments;
    }
    
    @ObjectDumperOptions(DumpMode.DEEP)
    public ArgumentContainerToken getContent() {
        return content;
    }
}
