/* $Id: QTIMaximaSessionExample.java 1930 2009-02-20 17:20:26Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.authoring.AuthoringGlobals;
import org.qtitools.mathassess.tools.qticasbridge.maxima.QTIMaximaSession;
import org.qtitools.mathassess.tools.qticasbridge.types.FloatValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.VariableWrapper;

import uk.ac.ed.ph.snuggletex.DOMOutputOptions;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConvertingPostProcessor;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;

import org.w3c.dom.Document;

/**
 * This demonstrates some general usage of {@link QTIMaximaSession}
 *
 * @author  David McKain
 * @version $Revision: 1930 $
 */
public final class QTIMaximaSessionExample {
    
     public static void main(String[] args) throws Exception {
        QTIMaximaSession session = new QTIMaximaSession();
        session.open();
        try {
            /* Set template variables defined within the QTI */
            session.passQTIVariableToMaxima("SCORE", new FloatValueWrapper(2.0));
            
            /* Set template variables via ScriptRule */
            session.executeScriptRule("mAns:6*x-10;"
                    + "mBad1:-10+6*x;"
                    + "mBad2:2*x-10+4*x;"
                    + "mBad3:6*x-5;"
                    + "mBad4:5*x-10;"
                    + "mBad5:6*x+10;"
                    + "mBad6:2*(3*x-5);"
                    + "mBad7:2*(x-5)+4*x;");
            
            /* Set RESPONSE variable via ScriptRule */
            session.executeScriptRule("RESPONSE: 6*x-10$");
            
            /* Extract values of the math variables */
            MathsContentValueWrapper mAns = session.queryMaximaVariable("mAns", MathsContentValueWrapper.class);
            System.out.println("Got mAns=" + mAns);
            
            MathsContentValueWrapper scoreAsMathsContent = session.queryMaximaVariable("SCORE", MathsContentValueWrapper.class);
            System.out.println("Got MathsContent score=" + scoreAsMathsContent);
            
            FloatValueWrapper scoreAsFloat = session.queryMaximaVariable("SCORE", FloatValueWrapper.class);
            System.out.println("Got float version of score=" + scoreAsFloat);
            
            /* Try to extract an undefined variable */
            System.out.println("Result of extracting undefined variable=" + session.queryMaximaVariable("silly", MathsContentValueWrapper.class));
            
            /* CasProcess example */
            FloatValueWrapper test1 = session.executeCasProcess("ev(SCORE^2,simp)", FloatValueWrapper.class);
            System.out.println("Got float result " + test1.getValue());
            
            MathsContentValueWrapper test2 = session.executeCasProcess("ev(SCORE^2,simp)", MathsContentValueWrapper.class);
            System.out.println("Got math result " + test2.getMaximaInput());
            
            /* CasCompare example */
            boolean result = session.executeCasCompare(QTIMaximaSession.MAXIMA_EQUAL_CODE, false,
                    new FloatValueWrapper(2.0),
                    new VariableWrapper("SCORE"));
            System.out.println("Got CasCompare result " + result);
            
            /* CasCondition example... same as above but done in a slightly different way! */
            result = session.executeCasCondition(QTIMaximaSession.MAXIMA_EQUAL_CODE, false,
                    new VariableWrapper("SCORE"),
                    session.executeMathOutput("2.0"));
            System.out.println("Got CasCondition result " + result);
            
            /* Variable Substitution.
             * 
             * Let's add 5 to mAns, doing the whole SnuggleTeX process for completeness!
             */
            SnuggleEngine engine = new SnuggleEngine();
            engine.registerDefinitions(AuthoringGlobals.getSnuggleTeXDefinitionMap());
            
            /* Now we do an example conversion */
            SnuggleSession snuggleSession = engine.createSession();
            DOMOutputOptions outputOptions = new DOMOutputOptions();
            outputOptions.setDOMPostProcessor(new UpConvertingPostProcessor());
            snuggleSession.parseInput(new SnuggleInput("$ \\qv{mAns} + 5 $"));
            String rawMathML = snuggleSession.buildXMLString(true);
            System.out.println("MathML for substitution is " + rawMathML);
            
            Document outputMathMLDocument = MathMLUtilities.parseMathMLDocumentString(rawMathML);
            session.substituteVariables(outputMathMLDocument.getDocumentElement());
            System.out.println("Substituted MathML is " + MathMLUtilities.serializeDocument(outputMathMLDocument));
        }
        finally {
            session.close();
        }
    }
}
