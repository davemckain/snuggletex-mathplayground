/* $Id: MathsContentTooComplexException.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentOutputValueWrapper;

/**
 * This Exception is thrown if a MathsContent value encoded inside a 
 * {@link MathsContentOutputValueWrapper} does not have the required amount of semantics
 * to be handled in the appropriate way.
 * <p>
 * Normally this will be thrown if some MathML output cannot be up-converted to being
 * Maxima input again.
 * <p>
 * This one's a bit awkward as the underlying problem could be:
 * <ul>
 *   <li>The up-conversion process isn't clever enough.</li>
 *   <li>The content was authored directly and is genuinely outside the scope of what we support.</li>
 *   <li>The content arose as part of a Maxima call and has now gone outside the scope of what we support.</li>
 * <ul>
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class MathsContentTooComplexException extends Exception {

    private static final long serialVersionUID = -3121152232236067772L;
    
    private final MathsContentOutputValueWrapper valueWrapper;
    
    public MathsContentTooComplexException(final MathsContentOutputValueWrapper valueWrapper) {
        super("MathsContent based on PMathML "
                + valueWrapper.getPMathML()
                + " cannot be up-converted into Maxima input format... probably too complex");
        this.valueWrapper = valueWrapper;
    }

    public MathsContentOutputValueWrapper getMathsContentValueWrapper() {
        return valueWrapper;
    }
}
