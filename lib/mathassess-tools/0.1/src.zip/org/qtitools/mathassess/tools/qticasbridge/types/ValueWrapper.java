/* $Id: ValueWrapper.java 1925 2009-02-17 13:43:58Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper that represents a QTI baseValue expression.
 * 
 * @see SingleValueWrapper
 * @see MultipleValueWrapper
 * @see OrderedValueWrapper
 * @see MathsContentValueWrapper
 *
 * @author  David McKain
 * @version $Revision: 1925 $
 */
public interface ValueWrapper extends ValueOrVariableWrapper {
    
    /** Returns the QTI cardinality of the given value. */
    ValueCardinality getCardinality();
    
    /** 
     * Tests whether the value represented by this wrapper is null or not.
     * 
     * @return true if null, false otherwise.
     */
    boolean isNull();
}
