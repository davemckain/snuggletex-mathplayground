/* $Id: MaximaRuntimeException.java 1883 2009-02-06 16:21:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima;

/**
 * Runtime Exception thrown to indicate an unexpected problem
 * encountered when communicating with Maxima.
 * <p>
 * This Exception is unchecked as there's nothing that can reasonably be done
 * to recover from this so ought to bubble right up to a handler near the "top"
 * of your application.
 * 
 * @author  David McKain
 * @version $Revision: 1883 $
 */
public class MaximaRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 7100573731627419599L;

    public MaximaRuntimeException(String message) {
        super(message);
    }

    public MaximaRuntimeException(Throwable cause) {
        super(cause);
    }

    public MaximaRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }
}
