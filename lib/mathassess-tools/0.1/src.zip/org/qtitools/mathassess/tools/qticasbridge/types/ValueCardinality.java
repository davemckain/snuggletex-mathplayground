/* $Id: ValueCardinality.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Encapsulates the different cardinalities for {@link ValueWrapper}s,
 * reflecting the same model in QTI.
 * <p>
 * Note that we've added a special {@link #MATHS_CONTENT}, which in
 * reality is being modelled as a QTI "record".
 * 
 * @see ValueWrapper
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public enum ValueCardinality {
    
    SINGLE,
    MULTIPLE,
    ORDERED,
    MATHS_CONTENT,
    ;

}
