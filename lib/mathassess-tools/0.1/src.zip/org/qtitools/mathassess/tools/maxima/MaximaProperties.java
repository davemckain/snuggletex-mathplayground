/* $Id: MaximaProperties.java 1896 2009-02-10 10:15:56Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Trivial helper class to read in values from the {@link Properties} file that is used to
 * configure Maxima at run-time.
 * 
 * @see #PROPERTIES_RESOURCE_NAME
 * 
 * @author  David McKain
 * @version $Revision: 1896 $
 */
public final class MaximaProperties {
    
    public static final String PROPERTIES_RESOURCE_NAME = "maxima.properties";
    
    public static final String MAXIMA_EXECUTABLE_PATH_PROPERTY_NAME = "org.qtitools.mathassess.tools.maxima.path";
    public static final String MAXIMA_ENVIRONMENT_PROPERTY_BASE_NAME = "org.qtitools.mathassess.tools.maxima.env";
    public static final String MAXIMA_TIMEOUT_PROPERTY_NAME = "org.qtitools.mathassess.tools.maxima.timeout";
    
    private static Properties maximaProperties;
    
    private static Properties ensureReadProperties() {
        if (maximaProperties==null) {
            InputStream propertiesStream = MaximaProperties.class.getClassLoader().getResourceAsStream(PROPERTIES_RESOURCE_NAME);
            if (propertiesStream==null) {
                throw new MaximaConfigurationException("Could not locate Maxima properties resource "
                        + PROPERTIES_RESOURCE_NAME
                        + " via the ClassLoader");
            }
            Properties temp = new Properties();
            try {
                temp.load(propertiesStream);
            }
            catch (IOException e) {
                throw new MaximaConfigurationException("IOException when reading Maxima properties resource "
                        + PROPERTIES_RESOURCE_NAME, e);
            }
            maximaProperties = temp;
        }
        return maximaProperties;
    }
    
    public static final String getProperty(String propertyName) {
        Properties maximaProperties = ensureReadProperties();
        return maximaProperties.getProperty(propertyName);
    }
    
    public static final String getRequiredProperty(String propertyName) {
        String result = getProperty(propertyName);
        if (result==null) {
            throw new MaximaConfigurationException("Required property " + propertyName
                    + " not specified in " + PROPERTIES_RESOURCE_NAME);
        }
        return result;
    }
}
