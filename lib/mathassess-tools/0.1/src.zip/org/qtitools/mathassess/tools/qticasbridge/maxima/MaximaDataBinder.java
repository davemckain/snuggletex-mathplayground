/* $Id: MaximaDataBinder.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.maxima;

import org.qtitools.mathassess.tools.qticasbridge.QTICASBridgeException;
import org.qtitools.mathassess.tools.qticasbridge.SpecUnimplementedException;
import org.qtitools.mathassess.tools.qticasbridge.types.CompoundValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MultipleValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.OrderedValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.SingleValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.StringValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.ValueOrVariableWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.ValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.VariableWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.WrapperUtilities;
import org.qtitools.mathassess.tools.utilities.ConstraintUtilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Helper class performing "data binding" tasks that establish mappings
 * between {@link ValueOrVariableWrapper}s and Maxima input/output.
 * 
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class MaximaDataBinder {

    //-------------------------------------------------------------------------------
    // Methods for converting QTI values to Maxima input forms
    
    /**
     * Converts the given {@link ValueOrVariableWrapper} to a corresponding Maxima
     * form that can be used a part of an input expression.
     * 
     * @throws IllegalArgumentException if the given wrapper is a
     *  {@link MathsContentValueWrapper} with a missing Maxima annotation, which indicates
     *  that the value passed hasn't been filled in correctly (or was maybe too complex, but
     *  this should have been checked in advance of calling this.)
     */
    public String toMaximaExpression(final ValueOrVariableWrapper argument) {
        ConstraintUtilities.ensureNotNull(argument, "variable or value");
        String result;
        if (argument instanceof VariableWrapper) {
            VariableWrapper variable = (VariableWrapper) argument;
            /* FIXME: What if variable name is not a legal maxima name? */
            result = variable.getIdentifier();
        }
        else if (argument instanceof ValueWrapper) {
            ValueWrapper valueWrapper = (ValueWrapper) argument;
            result = toMaximaExpression(valueWrapper);
        }
        else {
            throw new QTICASBridgeException("Unexpected logic branch");
        }
        return result;
    }
    
    @SuppressWarnings("unchecked")
    private String toMaximaExpression(final ValueWrapper valueWrapper) {
        ConstraintUtilities.ensureNotNull(valueWrapper, "value");
        switch (valueWrapper.getCardinality()) {
            case MATHS_CONTENT:
                MathsContentValueWrapper mathsContent = (MathsContentValueWrapper) valueWrapper;
                String maximaInput = mathsContent.getMaximaInput();
                if (maximaInput==null) {
                    throw new IllegalArgumentException("The maximaInput field must not be empty");
                }
                return maximaInput;
                
            case SINGLE:
                return toMaximaExpression((SingleValueWrapper) valueWrapper);
                
            case MULTIPLE:
                return toMaximaSet((MultipleValueWrapper) valueWrapper);

            case ORDERED:
                return toMaximaList((OrderedValueWrapper) valueWrapper);
                
            default:
                throw new SpecUnimplementedException("No current support for mapping values with cardinality "
                    + valueWrapper.getCardinality()
                    + " to Maxima input");
        }
    }
    
    private <B> String toMaximaExpression(final SingleValueWrapper<B> valueWrapper) {
        ConstraintUtilities.ensureNotNull(valueWrapper, "value");
        return toMaximaItem(valueWrapper);
    }
    
    private <B, S extends SingleValueWrapper<B>>
    String toMaximaSet(MultipleValueWrapper<B,S> wrapperSet) {
        return makeComposite(wrapperSet, "{", "}");
    }
    
    private <B, S extends SingleValueWrapper<B>>
    String toMaximaList(OrderedValueWrapper<B,S> wrapperSet) {
        return makeComposite(wrapperSet, "[", "]");
    }
    
    private <B, S extends SingleValueWrapper<B>>
    String makeComposite(Collection<S> collection, String opener, String closer) {
        StringBuilder resultBuilder = new StringBuilder(opener);
        String prefix = "";
        for (S entry : collection) {
            resultBuilder.append(prefix).append(toMaximaItem(entry));
            prefix = ", ";
        }
        resultBuilder.append(closer);
        return resultBuilder.toString();
    }
    
    private <B, S extends SingleValueWrapper<B>>
    String toMaximaItem(S item) {
        switch (item.getBaseType()) {
            case BOOLEAN:
            case FLOAT:
            case INTEGER:
                return item.getValue().toString();
                
//            case POINT:
//                PointValueWrapper pointValue = (PointValueWrapper) item;
//                return toMaximaList(pointValue.toIntegerOrderedValueWrapper());
               
            case STRING:
                String itemString = ((StringValueWrapper) item).getValue();
                return "\"" + itemString.replace("\"", "\\\"") + "\"";
                
            default:
                throw new SpecUnimplementedException("No support for mapping single variables of baseType "
                        + item.getBaseType() + " to Maxima input");
        }
    }
    
    //-------------------------------------------------------------------------------
    // General methods for getting results out of Maxima
    
    /**
     * Parses the output from Maxima's <tt>grind()$</tt> command, attempting to construct a
     * {@link ValueWrapper} Object of the type specified in resultClass.
     * If the Maxima output is compatible with this type then an appropriately populated Object
     * is returned representing the Maxima output, otherwise null is returned.
     * <p>
     * Note the the raw grind output provided is trimmed and any trailing '$' delimiter is removed.
     * 
     * @param rawGrindOutput raw output from <tt>grind(expr)$</tt>, which must not be null
     * @param resultClass Class of the desired result type
     * @param <V> the desired result type
     * 
     * @return instance of the required result type representing the grind() output, or null if
     *   the output could not be converted into the given type. (E.g. if called requesting to
     *   return an integer when the output from grind() is an expression).
     * 
     * @throws IllegalArgumentException if called with a {@link MathsContentValueWrapper} resultClass.
     */
    @SuppressWarnings("unchecked")
    public <V extends ValueWrapper>
    V parseGrindOutput(final String rawGrindOutput, final Class<V> resultClass) {
        ConstraintUtilities.ensureNotNull(rawGrindOutput, "grind() output");
        ConstraintUtilities.ensureNotNull(resultClass, "result Class");
        
        /* Clean up the grind() output by trimming off any whitespace and any left-over '$' terminator */
        String tidiedGrindOutput = rawGrindOutput.trim();
        if (tidiedGrindOutput.endsWith("$")) {
            tidiedGrindOutput = tidiedGrindOutput.substring(0, tidiedGrindOutput.length()-1);
        }
        
        /* Now parse */
        if (SingleValueWrapper.class.isAssignableFrom(resultClass)) {
            return (V) parseSingleGrindOutput(tidiedGrindOutput, (Class<? extends SingleValueWrapper>) resultClass);
        }
        else if (MultipleValueWrapper.class.isAssignableFrom(resultClass)) {
            return (V) parseMultipleGrindOutput(tidiedGrindOutput, (Class<? extends MultipleValueWrapper>) resultClass);
        }
        else if (OrderedValueWrapper.class.isAssignableFrom(resultClass)) {
            return (V) parseOrderedGrindOutput(tidiedGrindOutput, (Class<? extends OrderedValueWrapper>) resultClass);
        }
        else if (MathsContentValueWrapper.class.isInstance(resultClass)) {
            throw new IllegalArgumentException("This method should not be used to extract MathsContent values");
        }
        else {
            throw new SpecUnimplementedException("Support for parsing raw Maxima output into values of class " + resultClass
                    + " has not yet been implemented");
        }
    }
    
    @SuppressWarnings("unchecked")
    private <B, S extends SingleValueWrapper<B>>
    S parseSingleGrindOutput(final String grindOutput, final Class<S> resultClass) {
        S resultWrapper = WrapperUtilities.createSingleValue(resultClass);
        B resultContent = null;
        switch (resultWrapper.getBaseType()) {
            case STRING:
                String resultString = null;
                if (grindOutput.length()==0) {
                    /* grind("") yields an empty result, which is out of step with what follows */
                    resultString = "";
                }
                else if (grindOutput.startsWith("\"") && grindOutput.endsWith("\"")) {
                    resultString = grindOutput
                        .substring(1, grindOutput.length()-1)
                        .replace("\\\"", "\"");
                }
                resultContent = (B) resultString;
                break;
                
            case BOOLEAN:
                if (grindOutput.equals("true")) {
                    resultContent = (B) Boolean.TRUE;
                }
                else if (grindOutput.equals("false")) {
                    resultContent = (B) Boolean.FALSE;
                }
                break;
                
            case INTEGER:
                try {
                    resultContent = (B) Integer.valueOf(grindOutput); 
                }
                catch (NumberFormatException e) {
                    /* Continue to catch-all below */
                }
                break;
                
            case FLOAT:
                try {
                    resultContent = (B) Double.valueOf(grindOutput); 
                }
                catch (NumberFormatException e) {
                    /* Continue to catch-all below */
                }
                break;
                
            default:
                throw new SpecUnimplementedException("Support for parsing raw Maxima output fragments into "
                        + "single QTI values of baseType "
                        + resultWrapper.getBaseType()
                        + " has not yet been implemented");
        }
        /* If result is still null then parsing failed, so return null */
        if (resultContent==null) {
            return null;
        }
        resultWrapper.setValue(resultContent);
        return resultWrapper;
    }
    
    private <B, S extends SingleValueWrapper<B>, C extends MultipleValueWrapper<B,S>>
    C parseMultipleGrindOutput(final String grindOutput, final Class<C> resultClass) {
        return parseCompoundGrindOutput(grindOutput, "{", "}", resultClass);
    }
    
    private <B, S extends SingleValueWrapper<B>, C extends OrderedValueWrapper<B,S>>
    C parseOrderedGrindOutput(final String grindOutput, final Class<C> resultClass) {
        return parseCompoundGrindOutput(grindOutput, "[", "]", resultClass);
    }
    
    private <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>>
    C parseCompoundGrindOutput(final String grindOutput, final String opener, final String closer,
            final Class<C> resultClass) {
        C result = WrapperUtilities.createCompoundValue(resultClass);
        
        /* Bail out if not delimited appropriately */
        if (!(grindOutput.startsWith(opener) && grindOutput.endsWith(closer))) {
            return null;
        }
        String collectionContent = grindOutput.substring(opener.length(),
                grindOutput.length() + 1 - opener.length() - closer.length());
        
        /* Maxima's string outputs are a bit odd in that [] is output instead of [""],
         * [,] represents ["",""] etc. so we need to fix these up if that's the case
         */
        if (StringValueWrapper.class.isAssignableFrom(result.getItemClass())) {
            if (collectionContent.length()==0) {
                collectionContent = "\"\"";
            }
            else {
                collectionContent = collectionContent.replaceAll("(^|,),", "$1\"\",");
                collectionContent = collectionContent.replaceAll(",(,|$)", ",\"\"$1");
            }
        }
        
        /* Do a safe CSV split on it */
        List<String> itemStrings = splitCSVSafely(collectionContent);
        for (String itemString : itemStrings) {
            /* Parse each bit */
            Class<S> itemClass = result.getItemClass();
            S item = parseSingleGrindOutput(itemString, itemClass);
            if (item==null) {
                /* Parsing failed, so reject the whole Collection */
                return null;
            }
            result.add(item);
        }
        return result;
    }
    
    /**
     * Helper method to split up CSV that might delimit some fields inside double quotes, handling
     * commas correctly that might appear within these quotes.
     * <p>
     * (Note that any double quotes delimiting fields are kept in the results.)
     * @param collectionContent
     * @return
     */
    private static List<String> splitCSVSafely(final String collectionContent) {
        Pattern p = Pattern.compile("([^,]*)(,\\s*)?");
        Matcher m = p.matcher(collectionContent);
        
        List<String> result = new ArrayList<String>();
        String contentGroup = null;
        String commaGroup = null;
        boolean quoted = false;
        StringBuilder itemBuilder = new StringBuilder();
        while (m.find()) {
            contentGroup = m.group(1);
            commaGroup = m.group(2);
            if (contentGroup.length()==0 && commaGroup==null) {
                /* Found nothing */
                break;
            }
            if (quoted) {
                itemBuilder.append(contentGroup);
                if (contentGroup.endsWith("\"")) {
                    /* End of quote mode */
                    result.add(itemBuilder.toString());
                    itemBuilder.setLength(0);
                    quoted = false;
                }
                else {
                    /* Keep content and comma */
                    itemBuilder.append(commaGroup);
                }
            }
            else {
                if (contentGroup.startsWith("\"") && !(contentGroup.length() > 1 && contentGroup.endsWith("\""))) {
                    itemBuilder.append(contentGroup);
                    itemBuilder.append(commaGroup);
                    quoted = true;
                }
                else {
                    result.add(contentGroup);
                }
            }
        }
        if (quoted) {
            throw new QTICASBridgeException("Last opened double quotes were not closed");
        }
        return result;
    }
}
