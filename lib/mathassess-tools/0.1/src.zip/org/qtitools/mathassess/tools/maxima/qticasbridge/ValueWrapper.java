/* $Id: ValueWrapper.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Wrapper that represents the value of a QTI baseType expression.
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public interface ValueWrapper extends ValueOrVariableWrapper {
    
    ValueType getType();
    
}
