/* $Id$
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.upconversion;

import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConversionParameters;

import java.util.HashMap;
import java.util.Map;

/**
 * Some internal constants for the up-conversion process.
 *
 * @author  David McKain
 * @version $Revision$
 */
public final class UpConversionConstants {
    
    public static final Map<String,Object> UP_CONVERSION_PARAMETERS;
    
    static {
        UP_CONVERSION_PARAMETERS = new HashMap<String, Object>();
        UP_CONVERSION_PARAMETERS.put(UpConversionParameters.MAXIMA_OPERATOR_FUNCTION, "maOperator");
    }

}
