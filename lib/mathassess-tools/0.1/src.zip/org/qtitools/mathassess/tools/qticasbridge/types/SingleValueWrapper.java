/* $Id: SingleValueWrapper.java 1928 2009-02-18 11:36:01Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Base class for wrappers holding single-cardinality QTI values.
 * 
 * @param <B> Java type corresponding to the QTI base value being wrapped up
 *
 * @author  David McKain
 * @version $Revision: 1928 $
 */
public abstract class SingleValueWrapper<B> implements ValueWrapper {
    
    private B value;
    
    public SingleValueWrapper(final B value) {
        setValue(value);
    }
    
    public B getValue() {
        return value;
    }
    
    public void setValue(B value) {
        this.value = value;
    }
    
    public final ValueCardinality getCardinality() {
        return ValueCardinality.SINGLE;
    }
    
    public abstract ValueBaseType getBaseType();
    
    public boolean isNull() {
        return value==null;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" + value + ")";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SingleValueWrapper)) {
            return false;
        }
        SingleValueWrapper<?> other = (SingleValueWrapper<?>) obj;
        return value.equals(other.value);
    }
}
