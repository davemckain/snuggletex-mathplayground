/* $Id: QTICASBridgeException.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

/**
 * This Exception is thrown when something unexpected happens in the QTI/CAS bridge
 * code. This almost always indicates a logic failure or bug that needs to be investigated
 * and fixed.
 * <p>
 * Problems caused by bad authoring are raised using {@link BadQTICASCodeException}
 * 
 * @see BadQTICASCodeException
 * @see SpecUnimplementedException
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public class QTICASBridgeException extends RuntimeException {

    private static final long serialVersionUID = -3238153517339012903L;

    public QTICASBridgeException() {
        super();
    }

    public QTICASBridgeException(String message, Throwable cause) {
        super(message, cause);
    }

    public QTICASBridgeException(String message) {
        super(message);
    }

    public QTICASBridgeException(Throwable cause) {
        super(cause);
    }
}
