/* $Id: SpecUnimplementedException.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

/**
 * This Exception is thrown if something is attempted that has been
 * defined in the QTI/CAS bridge spec but has not yet been unimplemented.
 * 
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public class SpecUnimplementedException extends QTICASBridgeException {

    private static final long serialVersionUID = 3890296776080082123L;

    public SpecUnimplementedException() {
        super();
    }

    public SpecUnimplementedException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpecUnimplementedException(String message) {
        super(message);
    }

    public SpecUnimplementedException(Throwable cause) {
        super(cause);
    }
}
