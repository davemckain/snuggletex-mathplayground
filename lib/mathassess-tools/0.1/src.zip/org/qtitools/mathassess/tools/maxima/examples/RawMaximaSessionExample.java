/* $Id: RawMaximaSessionExample.java 1910 2009-02-12 11:55:19Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.maxima.MaximaTimeoutException;
import org.qtitools.mathassess.tools.maxima.RawMaximaSession;

import java.util.Arrays;

/**
 * Example of using the {@link RawMaximaSession} class.
 *
 * @author  David McKain
 * @version $Revision: 1910 $
 */
public final class RawMaximaSessionExample {
    
    public static void main(String[] args) throws MaximaTimeoutException {
        RawMaximaSession session = new RawMaximaSession();
        session.open();
        try {
            /* Trivial command, raw output */
            System.out.println("Ex 1:" + session.executeExpectingSingleOutput("1;"));
            
            /* Same, but with output parsed as a single output (as expected) */
            System.out.println("Ex 2:" + session.executeExpectingSingleOutput("1;"));
            
            /* Multiple commands, raw output */
            System.out.println("Ex 3:" + session.executeRaw("2;3;"));
            
            /* Same, but output parsed */
            System.out.println("Ex 4:" + Arrays.toString(session.executeExpectingMultipleLabels("2;3;")));
            
            /* Similar. Note that the last command was terminated with '$' which causes Maxima not
             * to output its result.
             */
            System.out.println("Ex 5:" + Arrays.toString(session.executeExpectingMultipleLabels("x;y;z;4$")));
            
            /* Funny command - returns a result as well as outputting to STDOUT */
            System.out.println("Ex 6:" + session.executeRaw("tex(1/2);"));
            
            /* Command that hangs Maxima */
            System.out.println("Ex 7 should cause a timeout...");
            try {
                session.executeRaw("1");
            }
            catch (MaximaTimeoutException e) {
                System.out.println("Ex 7 timed out, as expected");
            }
        }
        finally {
            session.close();
        }
    }
}
