/* $Id: QTIMaximaSession.java 1904 2009-02-11 17:31:27Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;
import uk.ac.ed.ph.snuggletex.definitions.Globals;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.MathMLUpConverter;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.StylesheetCache;
import uk.ac.ed.ph.snuggletex.utilities.UnwrappedParallelMathMLDOM;

import java.util.HashMap;
import java.util.Map;

import org.qtitools.mathassess.tools.authoring.AuthoringGlobals;
import org.qtitools.mathassess.tools.maxima.MaximaTimeoutException;
import org.qtitools.mathassess.tools.maxima.RawMaximaSession;
import org.qtitools.mathassess.tools.maxima.upconversion.MaximaMathMLUpConverter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Main entry point for performing MathAssess QTI-related interactions with Maxima.
 * 
 * <h2>Usage Notes</h2>
 * <ul>
 *   <li>
 *     An instance of this class should only be used by one Thread at a time but is serially
 *     reusable.
 *   </li>
 *   <li>
 *     Call {@link #open()} to start up a fresh Maxima session.
 *   </li>
 *   <li>
 *     Each method called that interacts with Maxima will be done in current Maxima session,
 *     so will have the (usually desired) side-effect of changing Maxima's state.
 *   </li>
 *   <li>
 *     Call {@link #close()} to close the underlying Maxima session.
 *   </li>
 *   <li>
 *     For examples, see the examples package. A test suite is on its way too...!
 *   </li>
 * </ul>
 * 
 * FIXME: Not all QTI types have been done yet... in particular strings!
 * FIXME: Need to think about randomisation seeds...
 * FIXME: Need to think about whether to allow all possible QTI variable identifier names, even if not legal Maxima.
 * 
 * @author  David McKain
 * @version $Revision: 1904 $
 */
public final class QTIMaximaSession {

    /** Maxima code for the <tt>equal</tt> action in <tt>CasCompare</tt> */
    public static final String MAXIMA_EQUAL_CODE = "is(equal($1=$2))";
    
    /** Maxima code for the <tt>syntequal<tt> action in <tt>CasCompare</tt> */
    public static final String MAXIMA_SYNTEQUAL_CODE = "is($1=$2)";
    
    /** Underlying Raw Maxima Session */
    private final RawMaximaSession rawMaximaSession;
    
    /** Maxima MathML up-converter */
    private final MaximaMathMLUpConverter maximaMathMLUpConverter;
    
    public QTIMaximaSession() {
        this(new DefaultStylesheetCache());
    }
    
    public QTIMaximaSession(StylesheetCache stylesheetCache) {
        this.rawMaximaSession = new RawMaximaSession();
        this.maximaMathMLUpConverter = new MaximaMathMLUpConverter(stylesheetCache);
    }
    
    //------------------------------------------------
    // Session lifecycle methods (delegates to underlying RawMaximaSession)
    
    public void open() throws MaximaTimeoutException {
        /* Open up the underlying session */
        rawMaximaSession.open();
        
        /* Load the MathML module */
        rawMaximaSession.executeRaw("load(mathml)$");
        
        /* Turn off simplification */
        rawMaximaSession.executeRaw("simp:false$");
    }
    
    public void close() {
        rawMaximaSession.close();
    }
    
    //------------------------------------------------
    // Methods for passing values of QTI variables to Maxima
    
    /**
     * Passes the given value of the given QTI variable to Maxima.
     * 
     * @param variableIdentifier QTI variable identifier.
     * @param wrapper representing the QTI value of the variable.
     */
    public void passQTIVariableToMaxima(final String variableIdentifier, final ValueWrapper valueWrapper) {
        /* Convert the QTI value to an appropriate Maxima expression */
        String maximaValue = toMaximaExpression(valueWrapper);
        
        /* Then do the appropriate Maxima call */
        try {
            rawMaximaSession.executeRaw(variableIdentifier + ": " + maximaValue + "$");
        }
        catch (MaximaTimeoutException e) {
            /* This shouldn't happen here! */
            throw new QTICASBridgeException("Unexpected timeout when setting Maxima variable "
                    + variableIdentifier + " to value " + maximaValue, e);
        }
    }
    
    /**
     * Useful convenience method that converts the given {@link ValueOrVariableWrapper} to
     * a Maxima expression that represents it.
     */
    public String toMaximaExpression(final ValueOrVariableWrapper argument) {
        String result;
        if (argument instanceof VariableWrapper) {
            VariableWrapper variable = (VariableWrapper) argument;
            /* FIXME: What if variable name is not a legal maxima name? */
            result = variable.getIdentifier();
        }
        else if (argument instanceof ValueWrapper) {
            ValueWrapper valueWrapper = (ValueWrapper) argument;
            result = toMaximaExpression(valueWrapper);
        }
        else {
            throw new RuntimeException("This can't happen!");
        }
        return result;
    }
    
    /**
     * Useful convenience method that converts the given {@link ValueWrapper} to
     * a Maxima expression representing it.
     */
    public String toMaximaExpression(final ValueWrapper valueWrapper) {
        switch (valueWrapper.getType()) {
            case BOOLEAN:
                return ((BooleanValueWrapper) valueWrapper).getValue() ? "true" : "false";
                
            case FLOAT:
                return Float.toString(((FloatValueWrapper) valueWrapper).getValue());
                
            case INTEGER:
                return Integer.toString(((IntegerValueWrapper) valueWrapper).getValue());
                
            case MATHS_CONTENT:
                MathsContentValueWrapper mathsContent = (MathsContentValueWrapper) valueWrapper;
                return mathsContent.getMaximaInput();
                
            default:
                throw new SpecUnimplementedException("No current support for mapping variables of type "
                        + valueWrapper.getType()
                        + " to Maxima input");
        }
    }
    
    //------------------------------------------------
    // Methods for getting Maxima to evaluate an expression and return (up-converted) MathML
    
    
    /**
     * Convenience method to evaluate the given Maxima expression, which is assumed to be
     * a single expression of the form "expr" or "expr;" returning a single result.
     * <p>
     * The implementation converts this to "mathml(expr);" and returns the result as a
     * {@link MathsContentValueWrapper}.
     */
    public MathsContentValueWrapper executeSingleMaximaExpression(final String maximaExpression)
            throws MaximaTimeoutException {
        /* Chop off trailing ';' temporarily */
        String resultingExpression = maximaExpression.replaceFirst(";+$", "");
        
        /* Convert to "mathml(expr);" format */
        resultingExpression = "mathml(" + resultingExpression + ");";
        
        /* Then execute and up-convert the results */
        String rawMathMLOutput = rawMaximaSession.executeRaw(resultingExpression);
        UnwrappedParallelMathMLDOM upconvertedMathML = upconvertRawMaximaMathML(rawMathMLOutput);
        
        /* We'll record the raw MathML as well, as it's useful for debugging */
        MathsContentValueWrapper result = BridgeUtilities.unwrapUpconvertedMathMLDocument(upconvertedMathML);
        result.setRawMaximaPMathML(rawMathMLOutput);
        return result;
    }
    
    /**
     * Takes raw MathML returned from Maxima via the <tt>mathml.lisp</tt> module and up-converts
     * it into annotated MathML, returning a convenience {@link UnwrappedParallelMathMLDOM}
     * containing all of the various parts of the resulting MathML.
     * <p>
     * It also checks for any failures in the up-conversion process, throwing a
     * {@link QTICASBridgeException} if that happens.
     * 
     * @throws QTICASBridgeException if the up-conversion process failed, which indicates that
     *   the process needs amended and fixed (or possibly that what was attempted exceeds the
     *   scope of what we're trying to do.)
     */
    public UnwrappedParallelMathMLDOM upconvertRawMaximaMathML(final String rawMaximaMathMLOutput) {
        /* Up-convert the raw MathML */
        Document upconvertedDocument = maximaMathMLUpConverter.upconvertRawMaximaMathML(rawMaximaMathMLOutput);
        
        /* Make sure there were no up-conversion failures */
        UnwrappedParallelMathMLDOM unwrappedDocument = MathMLUtilities.unwrapParallelMathMLDOM(upconvertedDocument.getDocumentElement());
        Map<String, NodeList> xmlAnnotations = unwrappedDocument.getXmlAnnotaions();
        if (xmlAnnotations.containsKey(MathMLUpConverter.CONTENT_FAILURES_ANNOTATION_NAME)) {
            throw new QTICASBridgeException("Up-conversion of Maxima MathML output to Content MathML reported errors");
        }
        else if (xmlAnnotations.containsKey(MathMLUpConverter.MAXIMA_ANNOTATION_NAME)) {
            throw new QTICASBridgeException("Up-conversion of Maxima MathML output back to Maxima input reported errors");
        }
        return unwrappedDocument;
    }
    
    //------------------------------------------------
    // Methods for extracting values of variables back from Maxima
    
    /**
     * Asks Maxima to return the value of the variable with the given identifier in a form
     * matching the given returnType.
     * <p>
     * Note that it's legal to ask Maxima to return the value of any variable as a
     * MathsContent value, even if it wasn't defined that way at first. The converse isn't
     * necessarily trough, though, so think carefully whether any attempted "casts" are legal.
     * 
     * FIXME: Check that variableIdentifier is legal and non-empty!
     * 
     * @param variableIdentifier code to be executed returning a single value of the given type
     * @param returnType required return type
     * 
     * @return wrapper encapsulating the resulting QTI value of the given variable, or null
     *   if it isn't defined.
     * 
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the given Maxima expression does not return an
     *   expression of the required returnType.
     */
    public ValueWrapper queryVariable(final String variableIdentifier, final ValueType returnType) {
        try {
            /* First of all, we'll check whether the variable is actually defined by asking Maxima
             * to return it in its usual way.
             */
            String maximaInput = variableIdentifier + ";";
            String rawLineOutput = rawMaximaSession.executeExpectingSingleOutput(maximaInput);
            
            /* If we got the variable name back, then it wasn't defined */
            if (variableIdentifier.equals(rawLineOutput)) {
                /* Variable not defined */
                return null;
            }
                
            /* What we do next depends on whether we are returning a MathsContent variable or not. */
            ValueWrapper result;
            if (returnType==ValueType.MATHS_CONTENT) {
                /* We ask Maxima again, this time returning MathML */
                result = executeSingleMaximaExpression(variableIdentifier);
            }
            else {
                /* We have to parse the raw output according to the desired return type,
                 * which might not always make sense.
                 * 
                 * For example, if we're expecting a float then remember that 2.0^2 is not going to
                 * be parsed as a float unless the author has explicitly requested it be simplified!!!
                 */
                result = parsePrimitiveMaximaOutput(maximaInput, rawLineOutput, returnType);
            }
            return result;
        }
        catch (MaximaTimeoutException e) {
            throw new QTICASBridgeException("Unexpected timeout occurred while extracting the value of variable "
                    + variableIdentifier, e);
        }
        catch (BadQTICASCodeException e) {
            throw new QTICASBridgeException("Could not cast value of variable " + variableIdentifier
                    + " to " + returnType, e);
        }
    }
        
    private ValueWrapper parsePrimitiveMaximaOutput(final String maximaCode, final String rawLineOutput, final ValueType returnType)
            throws BadQTICASCodeException {
        switch (returnType) {
            case MATHS_CONTENT:
                /* This is not "primitive" */
                throw new QTICASBridgeException("This method should not be used to extract MathsContent");
                
            case BOOLEAN:
                if (rawLineOutput.equals("true")) {
                    return new BooleanValueWrapper(true);
                }
                else if (rawLineOutput.equals("false")) {
                    return new BooleanValueWrapper(false);
                }
                else {
                    throw new BadQTICASCodeException("Maxima code " + maximaCode
                            + " returned " + rawLineOutput
                            + " which could not be cast to a boolean as requested");
                }
                
            case INTEGER:
                try {
                    return new IntegerValueWrapper(Integer.parseInt(rawLineOutput)); 
                }
                catch (NumberFormatException e) {
                    throw new BadQTICASCodeException("Maxima code " + maximaCode
                            + " returned " + rawLineOutput
                            + " which could not be cast to an integer as requested");
                }
                
            case FLOAT:
                try {
                    return new FloatValueWrapper(Float.parseFloat(rawLineOutput)); 
                }
                catch (NumberFormatException e) {
                    throw new BadQTICASCodeException("Maxima code " + maximaCode
                            + " returned " + rawLineOutput
                            + " which could not be cast to a float as requested");
                }
                
            default:
                throw new SpecUnimplementedException("Support for parsing raw Maxima output into variables of type " + returnType
                        + " has not yet been implemented");
        }
    }
    
    //------------------------------------------------
    // Bridge methods for custom QTI elements
    
    /**
     * Performs the CAS work for <tt>ScriptRule</tt>.
     * 
     * @param maximaCode maxima code to be executed
     * 
     * @throws MaximaTimeoutException
     */
    public void executeScriptRule(final String maximaCode) throws MaximaTimeoutException {
        rawMaximaSession.executeRaw(maximaCode);
    }
    
    /**
     * Performs the CAS work for <tt>CasProcess</tt>
     * 
     * @param maximaCode code to be executed returning a single value of the given type
     * @param returnType required return type
     * 
     * @return wrapper encapsulating the resulting QTI value
     * 
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the given Maxima expression does not return an
     *   expression of the required returnType.
     */
    public ValueWrapper executeCasProcess(final String maximaCode, final ValueType returnType)
            throws BadQTICASCodeException, MaximaTimeoutException  {
        /* What we do here depends on whether we are returning a MathsContent variable or not. */
        ValueWrapper result;
        if (returnType==ValueType.MATHS_CONTENT) {
            /* This is easier than you think! */
            result = executeSingleMaximaExpression(maximaCode);
        }
        else {
            /* This one is actually a bit harder as we have to parse the raw output according
             * to the desired return type, which might not always make sense.
             * 
             * For example, if we're expecting a float then remember that 2.0^2 is not going to
             * be parsed as a float unless the author has explicitly requested it be simplified!!!
             * 
             * First of all, we'll be nice and add a ';' to the maximaCode if required
             */
            String maximaInput = maximaCode;
            if (!maximaInput.endsWith(";")) {
                maximaInput += ";";
            }
            
            /* Then we'll execute the code and get the raw result back, expecting a single line */
            String rawLineOutput = rawMaximaSession.executeExpectingSingleOutput(maximaInput);
            
            /* Now we need to parse the raw output as appropriate */
            result = parsePrimitiveMaximaOutput(maximaInput, rawLineOutput, returnType);
        }
        return result;
    }

    /**
     * Performs the CAS work for <tt>CasCompare</tt> when authored with an explicit Maxima
     * code expression.
     * <p>
     * NOTE: The code passed here should <strong>NOT</strong> have a leading "casresult:"
     * string in it!
     * 
     * @param comparisonCode Maxima code that does the comparison work, expected to return
     *   a boolean value.
     * @param arg1 encapsulates the first value/variable to be compared
     * @param arg2 encapsulates the second value/variable to be compared
     * 
     * @return true or false
     * 
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the resulting Maxima call does not
     *   return either true or false
     */
    public boolean executeCasCompare(final String comparisonCode, final ValueOrVariableWrapper arg1,
            final ValueOrVariableWrapper arg2)
            throws MaximaTimeoutException, BadQTICASCodeException {
        return executeCasCondition(comparisonCode, arg1, arg2);
    }
    
    /**
     * Performs the CAS work for <tt>CasCondition</tt>
     * 
     * @param comparisonCode Maxima code that does the comparison work, expected to return
     *   a boolean value.
     * @param arguments array of arguments to be substituted into the Maxima code
     * 
     * @return true or false as reported by Maxima evaluating the given condition
     * 
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the resulting Maxima call does not
     *   return either true or false
     */
    public boolean executeCasCondition(final String comparisonCode, final ValueOrVariableWrapper... arguments)
            throws MaximaTimeoutException, BadQTICASCodeException {
        /* Be nice */
        String maximaInput = comparisonCode;
        if (!maximaInput.endsWith(";")) {
            maximaInput = maximaInput + ";";
        }
        
        /* Get maxima forms of the input values and perform substitutions */
        for (int i=0; i<arguments.length; i++) {
            maximaInput = maximaInput.replaceAll(
                    "(?<!\\$)\\$" + (i+1), /* (Using negative look-behind to allow things like $$) */
                    "(" + toMaximaExpression(arguments[i]) + ")" /* (Add extra brackets for safety) */
            );
        }
        
        /* Now do the call */
        String rawOutput = rawMaximaSession.executeExpectingSingleOutput(maximaInput);
        BooleanValueWrapper booleanWrapper = (BooleanValueWrapper) parsePrimitiveMaximaOutput(maximaInput, rawOutput, ValueType.BOOLEAN);
        return booleanWrapper.getValue();
    }
    
    //------------------------------------------------
    // Substitution of sub-expressions in MathML

    public void substituteVariables(Element rawMathMLElement)
            throws MaximaTimeoutException, BadQTICASCodeException {
        /* We'll create a little hash to store variable lookups as we traverse the <math/>
         * element just in case we have the same variable more than once. This will save
         * having to make extra calls.
         */
        Map<String,MathsContentValueWrapper> valuesCache = new HashMap<String, MathsContentValueWrapper>();
        
        /* Now walk the <math/> XML tree making substitutions as required, grafting into the tree */
        doSubstituteVariables(rawMathMLElement, valuesCache);
    }
    
    private void doSubstituteVariables(Element mathMLElement, Map<String,MathsContentValueWrapper> valuesCache)
            throws MaximaTimeoutException, BadQTICASCodeException {
        /* Search child elements */
        NodeList childNodes = mathMLElement.getChildNodes();
        Node childNode;
        Element childElement;
        for (int i=0, size=childNodes.getLength(); i<size; i++) {
            childNode = childNodes.item(i);
            if (childNode.getNodeType()==Node.ELEMENT_NODE) {
                childElement = (Element) childNode;
                if (childElement.getLocalName().equals("mi")
                        && childElement.getNamespaceURI().equals(Globals.MATHML_NAMESPACE)) {
                    doHandleMiElement(childElement, valuesCache);
                }
                else {
                    /* Continue recursively.
                     * FIXME: Should we worry about possible stack overflow by flattening this out?
                     */
                    doSubstituteVariables(childElement, valuesCache);
                }
            }
        }
    }
    
    private void doHandleMiElement(Element miElement, Map<String,MathsContentValueWrapper> valuesCache)
            throws BadQTICASCodeException {
        String varIdentifier;
        MathsContentValueWrapper mathValue;
        if (AuthoringGlobals.ENCODE_PLACEHOLDER_AS_ATTRIBUTE) {
            /* See if we've got a special attribute */
            varIdentifier = miElement.getAttributeNS(AuthoringGlobals.MATHASSESS_NS, "varIdentifier");
            if (varIdentifier!=null) {
                /* Extract value */
                mathValue = doExtractValue(varIdentifier, valuesCache);
                if (mathValue==null) {
                    throw new BadQTICASCodeException("Variable with identifier " + varIdentifier
                            + " specified for substitution within MathML is not defined in Maxima");
                }
                /* Make substitution */
                doSubstituteVariableValue(miElement, mathValue);
            }
        }
        else {
            /* Extract text content and see if it's a variable */
            StringBuilder contentBuilder = new StringBuilder();
            NodeList contentList = miElement.getChildNodes();
            for (int iInner=0, sizeInner=contentList.getLength(); iInner<sizeInner; iInner++) {
                contentBuilder.append(contentList.item(iInner).getNodeValue());
            }
            varIdentifier = contentBuilder.toString();
            if (varIdentifier.length()>0) {
                mathValue = doExtractValue(varIdentifier, valuesCache);
                if (mathValue!=null) {
                    /* It's defined in Maxima, so make the subs */
                    doSubstituteVariableValue(miElement, mathValue);
                }
            }
        }
    }
    
    private MathsContentValueWrapper doExtractValue(final String varIdentifier, final Map<String,MathsContentValueWrapper> valuesCache) {
        /* Note that we're caching 'null' lookups here */
        MathsContentValueWrapper result = null;
        if (valuesCache.containsKey(varIdentifier)) {
            result = valuesCache.get(varIdentifier);
        }
        else {
            result = (MathsContentValueWrapper) queryVariable(varIdentifier, ValueType.MATHS_CONTENT);
            valuesCache.put(varIdentifier, result);
        }
        return result;
    }
    
    private void doSubstituteVariableValue(Element miElement, final MathsContentValueWrapper value) {
        /* Import the PMathML into this document */
        Node parentNode = miElement.getParentNode();
        Node importedNode = parentNode.getOwnerDocument().adoptNode(value.getPMathMLElement());
        
        /* Replace element with this value */
        parentNode.replaceChild(importedNode, miElement);
    }
}
