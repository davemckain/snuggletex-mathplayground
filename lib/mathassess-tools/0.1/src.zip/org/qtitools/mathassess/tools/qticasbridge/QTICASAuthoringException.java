/* $Id: QTICASAuthoringException.java 1955 2009-03-04 17:13:58Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

/**
 * Base class for Exceptions thrown by the QTI/CAS code that's most likely due to
 * bad authoring.
 * 
 * @see BadQTICASCodeException
 * @see TypeConversionException
 *
 * @author  David McKain
 * @version $Revision: 1955 $
 */
public class QTICASAuthoringException extends RuntimeException {

    private static final long serialVersionUID = -3238153517339012903L;

    public QTICASAuthoringException() {
        super();
    }

    public QTICASAuthoringException(String message, Throwable cause) {
        super(message, cause);
    }

    public QTICASAuthoringException(String message) {
        super(message);
    }

    public QTICASAuthoringException(Throwable cause) {
        super(cause);
    }
}
