/* $Id: ValueOrVariableWrapper.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Marker interface representing either a QTI variable or a baseType value.
 * <p>
 * This is useful for some CAS operations which expect either a value (expression) or the
 * name of an existing variable.
 * 
 * @see ValueWrapper
 * @see VariableWrapper
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public interface ValueOrVariableWrapper {
    
    /* (Nothing here) */

}
