/* $Id: ValueType.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Encapsulates the different QTI types that will be passed
 * to/from the CAS system.
 * 
 * @see ValueWrapper
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public enum ValueType {
    
    /* TODO: Add more types as we support them... */
    
    BOOLEAN,
    INTEGER,
    FLOAT,
    MATHS_CONTENT,
    ;

}
