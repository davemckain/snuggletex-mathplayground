/* $Id: MaximaMathMLFixer.java 1908 2009-02-12 10:49:01Z davemckain $
 *
 * Copyright 2008 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.upconversion;

import org.qtitools.mathassess.tools.maxima.qticasbridge.QTICASBridgeException;

import uk.ac.ed.ph.snuggletex.SnuggleConstants;
import uk.ac.ed.ph.snuggletex.SnuggleRuntimeException;
import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;
import uk.ac.ed.ph.snuggletex.internal.XMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.StylesheetCache;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;

/**
 * Fixes up the raw MathML produced by Maxima output into a form roughly equivalent to the
 * Presentation MathML produced by SnuggleTeX.
 * 
 * (This is a blatant rip-off of the code that does the same for ASCIIMathML output in SnuggleTeX!)
 * 
 * @author  David McKain
 * @version $Revision: 1908 $
 */
final class MaximaMathMLFixer {

    /** Explicit name of the SAXON 9.X TransformerFactoryImpl Class */
    private static final String SAXON_TRANSFORMER_FACTORY_CLASS_NAME = "net.sf.saxon.TransformerFactoryImpl";
    
    /** Package to load various resources from */
    private static final String RESOURCE_PACKAGE = "org/qtitools/mathassess/tools/maxima/upconversion";
    
    /** "Base" location for the XSLT stylesheets used here */
    private static final String BASE_XSLT_URI = "classpath:/" + RESOURCE_PACKAGE;
    
    /** Location of the initial XSLT for fixing up ASCIIMathML */
    private static final String FIXER_XSLT_URI = BASE_XSLT_URI + "/maxima-output-fixer.xsl";
    
    /** Location of the resource providing {@link #entitySubstitutionProperties} */
    private static final String ENTITY_SUBSTITUTION_PROPERTIES_RESOURCE = RESOURCE_PACKAGE + "/maxima-entity-substitutions.properties";
    
    /** XSLT cache to use */
    private final StylesheetCache stylesheetCache;
    
    /** 
     * Properties mapping XML character entitity names to substitutions.
     * (I'm doing it this way as that mathml.lisp module doesn't output a lot of entities
     * so it's not worth pulling in the various entity files that form part of the MathML DTD.)
     */
    private final Properties entitySubstitutionProperties;
    
    /**
     * Creates a new up-converter using a simple internal cache.
     * <p>
     * Use this constructor if you don't use XSLT yourself. In this case, you'll want your
     * instance of this class to be reused as much as possible to get the benefits of caching.
     */
    public MaximaMathMLFixer() {
        this(new DefaultStylesheetCache());
    }
    
    /**
     * Creates a new up-converter using the given {@link StylesheetCache} to cache internal XSLT
     * stylesheets.
     * <p>
     * Use this constructor if you do your own XSLT caching that you want to integrate in, or
     * if the default doesn't do what you want.
     */
    public MaximaMathMLFixer(final StylesheetCache stylesheetCache) {
        this.stylesheetCache = stylesheetCache;
        this.entitySubstitutionProperties = loadEntitySubstitutionProperties();
    }
    
    private Properties loadEntitySubstitutionProperties() {
        Properties result = new Properties();
        InputStream resourceStream = getClass().getClassLoader().getResourceAsStream(ENTITY_SUBSTITUTION_PROPERTIES_RESOURCE);
        if (resourceStream==null) {
            throw new QTICASBridgeException("Could not locate entity substitutions resource within ClassPath "
                    + ENTITY_SUBSTITUTION_PROPERTIES_RESOURCE);
        }
        try {
            result.load(resourceStream);
        }
        catch (IOException e) {
            throw new QTICASBridgeException("Could not read in entity substitutions resource at "
                    + ENTITY_SUBSTITUTION_PROPERTIES_RESOURCE);
        }
        return result;
    }
    
    public Document fixMaximaMathMLOutput(final Document document, final Map<String, Object> upconversionParameters) {
        Document resultDocument = XMLUtilities.createNSAwareDocumentBuilder().newDocument();
        try {
            /* Create required XSLT */
            Templates upconverterStylesheet = getStylesheet(FIXER_XSLT_URI);
            Transformer upconverter = upconverterStylesheet.newTransformer();
            
            /* Set any specified parameters */
            if (upconversionParameters!=null) {
                for (Entry<String, Object> entry : upconversionParameters.entrySet()) {
                    /* (Recall that the actual stylesheets assume the parameters are in the SnuggleTeX
                     * namespace, so we need to use {uri}localName format for the parameter name.) */
                    upconverter.setParameter("{" + SnuggleConstants.SNUGGLETEX_NAMESPACE + "}" + entry.getKey(),
                            entry.getValue());
                }
            }
            
            /* Do the transform */
            upconverter.transform(new DOMSource(document), new DOMResult(resultDocument));
        }
        catch (TransformerException e) {
            throw new SnuggleRuntimeException("Fixing failed", e);
        }
        return resultDocument;
    }
    
    public Document fixMaximaMathMLOutput(final String maximaMathMLString, final Map<String, Object> upconversionParameters) {
        /* The Maxima MathML module outputs certain characters as entities. We'll replace them now */
        Pattern entityPattern = Pattern.compile("&(.+?);");
        Matcher entityMatcher = entityPattern.matcher(maximaMathMLString);
        StringBuffer replacementBuilder = new StringBuffer();
        String entityName, entityReplacement;
        while (entityMatcher.find()) {
            entityName = entityMatcher.group(1);
            entityReplacement = entitySubstitutionProperties.getProperty(entityName);
            if (entityReplacement==null) {
                throw new QTICASBridgeException("No substitution specified for character entitiy &"
                        + entityName + ";");
            }
            entityMatcher.appendReplacement(replacementBuilder, entityReplacement);
        }
        entityMatcher.appendTail(replacementBuilder);
        
        /* Now parse the MathML */
        String entityFreeMathMLString = replacementBuilder.toString();
        Document mathMLDocument;
        try {
            mathMLDocument = MathMLUtilities.parseMathMLDocumentString(entityFreeMathMLString);
        }
        catch (Exception e) {
            throw new QTICASBridgeException("Failed to parse raw MathML output from Maxima", e);
        }
        
        /* The fix up */
        return fixMaximaMathMLOutput(mathMLDocument, upconversionParameters);
    }
    
    //---------------------------------------------------------------------
    // Internal helpers
    
    private TransformerFactory createSaxonTransformerFactory() {
        try {
            /* We call up SAXON explicitly without going through the usual factory path */
            return (TransformerFactory) Class.forName(SAXON_TRANSFORMER_FACTORY_CLASS_NAME).newInstance();
        }
        catch (Exception e) {
            throw new SnuggleRuntimeException("Failed to explicitly instantiate SAXON "
                    + SAXON_TRANSFORMER_FACTORY_CLASS_NAME
                    + " class - check your ClassPath!", e);
        }
    }
    
    private Templates getStylesheet(String location) {
        Templates result;
        if (stylesheetCache==null) {
            result = compileStylesheet(location);
        }
        else {
            synchronized(stylesheetCache) {
                result = stylesheetCache.getStylesheet(location);
                if (result==null) {
                    result = compileStylesheet(location);
                    stylesheetCache.putStylesheet(location, result);
                }
            }
        }
        return result;
    }
    
    private Templates compileStylesheet(String location) {
        TransformerFactory transformerFactory = createSaxonTransformerFactory();
        return XMLUtilities.compileInternalStylesheet(transformerFactory, location);
    }
}
