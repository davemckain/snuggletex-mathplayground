/* $Id: ASCIIMathMLHelper.java 1999 2009-03-15 22:29:41Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

import org.qtitools.mathassess.tools.maxima.upconversion.UpConversionConstants;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentOutputValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentSource;
import org.qtitools.mathassess.tools.qticasbridge.types.WrapperUtilities;
import org.qtitools.mathassess.tools.utilities.ConstraintUtilities;

import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.MathMLUpConverter;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.StylesheetCache;

import org.w3c.dom.Document;

/**
 * Helper class that takes the raw input and output from ASCIIMathML and runs the up-conversion
 * process on it, creating a {@link MathsContentOutputValueWrapper} that can be picked apart
 * as required.
 * 
 * <h2>Usage Notes</h2>
 * 
 * Consider passing a shared instance of a {@link StylesheetCache} so that the underlying XSLT
 * stylesheets can be reused.
 *
 * @author  David McKain
 * @version $Revision: 1999 $
 */
public final class ASCIIMathMLHelper {
    
    private final MathMLUpConverter mathMLUpConverter;
    
    public ASCIIMathMLHelper() {
        this(new DefaultStylesheetCache());
    }
    
    public ASCIIMathMLHelper(StylesheetCache stylesheetCache) {
        this.mathMLUpConverter = new MathMLUpConverter(stylesheetCache);
    }
    
    /**
     * Takes the raw input and output from ASCIIMathML and up-converts it, creating a
     * {@link MathsContentOutputValueWrapper} filled in with all of the relevant details.
     * If the up-conversion process fails because the input was too complex, then a
     * {@link MathsContentTooComplexException} is thrown. 
     * 
     * @param asciiMathInput raw input entered into the ASCIIMathML box (e.g. '4sin x')
     * @param rawASCIIMathMLOutput raw Presentation MathML obtained from the ASCIIMathML
     *   JavaScript code.
     * 
     * @return filled in {@link MathsContentOutputValueWrapper}
     * 
     * @throws IllegalArgumentException if any of the required arguments are null
     * @throws MathsContentTooComplexException if the up-conversion process failed because
     *   the input was deemed too complex.
     * @throws QTICASBridgeException if the raw MathML from ASCIIMath could not be parsed 
     */
    public MathsContentOutputValueWrapper createMathsContentFromASCIIMath(final String asciiMathInput,
            final String rawASCIIMathMLOutput) throws MathsContentTooComplexException {
        ConstraintUtilities.ensureNotNull(asciiMathInput, "asciiMathInput");
        ConstraintUtilities.ensureNotNull(rawASCIIMathMLOutput, "rawAsciiMathMLOutput");
        Document asciiMathMLDocument;
        try {
            asciiMathMLDocument = MathMLUtilities.parseMathMLDocumentString(rawASCIIMathMLOutput);
        }
        catch (Exception e) {
            throw new QTICASBridgeException("Raw ASCIIMathML output could not be parsed", e);
        }
        Document upconvertedDocument = mathMLUpConverter.upConvertASCIIMathML(asciiMathMLDocument, UpConversionConstants.UP_CONVERSION_PARAMETERS);
        
        /* Create appropriate wrapper */
        MathsContentOutputValueWrapper result = WrapperUtilities.createFromUpconvertedMathMLDocument(MathsContentSource.STUDENT_MATH_ENTRY_INTERACTION, upconvertedDocument);
        result.setAsciiMathInput(asciiMathInput);
        result.setRawPMathML(rawASCIIMathMLOutput);
        
        /* Fail fast if there were any up-conversion failures */
        if (result.getUpconversionFailures()!=null) {
            throw new MathsContentTooComplexException(result);
        }
        return result;
    }
}
