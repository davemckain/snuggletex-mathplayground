/* $Id: FloatValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper representing a QTI float value.
 * <p>
 * (NOTE: This is a 64-bit IEEE Double precision float, which corresponds to a Java
 * <tt>double</tt> rather than a <float>.)
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class FloatValueWrapper extends SingleValueWrapper<Double> {
    
    public FloatValueWrapper() {
        this(Double.valueOf(0.0));
    }
    
    public FloatValueWrapper(final double value) {
        super(Double.valueOf(value));
    }
    
    
    public FloatValueWrapper(final Double value) {
        super(value);
    }
    
    @Override
    public ValueBaseType getBaseType() {
        return ValueBaseType.FLOAT;
    }
}
