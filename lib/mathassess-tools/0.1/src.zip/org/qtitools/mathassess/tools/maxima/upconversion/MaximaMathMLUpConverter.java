/* $Id: MaximaMathMLUpConverter.java 1999 2009-03-15 22:29:41Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.upconversion;

import org.qtitools.mathassess.tools.qticasbridge.maxima.QTIMaximaSession;

import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.MathMLUpConverter;
import uk.ac.ed.ph.snuggletex.utilities.StylesheetCache;

import org.w3c.dom.Document;

/**
 * Simple helper class that up-converts the raw MathML obtained from Maxima,
 * creating a much nicer and richer annotated MathML element.
 * <p>
 * (This just bootstraps over the raw {@link MaximaMathMLFixer} and the SnuggleTeX
 * up-conversion logic to do everything in one convenient step.)
 *
 * @author  David McKain
 * @version $Revision: 1999 $
 */
public final class MaximaMathMLUpConverter {
    
    /** Used to fix up the MathML coming out of Maxima */
    private final MaximaMathMLFixer mathMLFixer;
    
    /** SnuggleTeX MathML up-converter */
    private final MathMLUpConverter mathMLUpConverter;
    
    public MaximaMathMLUpConverter() {
        this(new DefaultStylesheetCache());
    }
    
    public MaximaMathMLUpConverter(StylesheetCache stylesheetCache) {
        this.mathMLFixer = new MaximaMathMLFixer(stylesheetCache);
        this.mathMLUpConverter = new MathMLUpConverter(stylesheetCache);
    }
    
    /**
     * Takes raw MathML returned from Maxima via the <tt>mathml.lisp</tt> module and attempts to
     * up-convert it into annotated MathML, returning a DOM {@link Document} Object.
     * <p>
     * <strong>NOTE:</strong> If you are calling this directly, then it is your responsibility to
     * check the annotations to make sure there were no failures. (The corresponding higher-level
     * code in {@link QTIMaximaSession} does this for you.)
     * 
     * @param rawMaximaMathMLOutput MathML output from Maxima, which doesn't need to have been
     *   trimmed or tidied up.
     */
    public Document upconvertRawMaximaMathML(final String rawMaximaMathMLOutput) {
        /* First of all, trim off labels and other extraneous stuff */
        String mathMLElementString = rawMaximaMathMLOutput.replaceFirst("(?s)^.+(<math)", "$1")
            .replaceFirst("(?s)(</math>).+$", "$1");

        /* Then fix up the MathML... */
        Document fixedDocument = mathMLFixer.fixMaximaMathMLOutput(mathMLElementString);
        
        /* ...then up-convert */
        return mathMLUpConverter.upConvertSnuggleTeXMathML(fixedDocument, UpConversionConstants.UP_CONVERSION_PARAMETERS);
    }
}
