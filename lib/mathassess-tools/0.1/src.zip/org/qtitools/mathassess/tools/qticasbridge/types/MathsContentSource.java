/* $Id: MathsContentSource.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Trivial enumeration of the various "sources" for a {@link MathsContentOutputValueWrapper}.
 * <p>
 * This isn't really used anywhere but is useful for debugging, logging and documentation.
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public enum MathsContentSource {
    
    /**
     * Indicates that a {@link MathsContentOutputValueWrapper} was created from a
     * candidate response to a MathEntryInteraction.
     */
    STUDENT_MATH_ENTRY_INTERACTION,
    
    /**
     * Indicates that a {@link MathsContentOutputValueWrapper} was created as a
     * response from the CAS (i.e. Maxima).
     */
    CAS_OUTPUT,
    
    ;

}
