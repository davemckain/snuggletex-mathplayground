/* $Id: WrapperUtilities.java 1999 2009-03-15 22:29:41Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

import org.qtitools.mathassess.tools.qticasbridge.QTICASBridgeException;

import uk.ac.ed.ph.snuggletex.extensions.upconversion.MathMLUpConverter;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConversionUtilities;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.UnwrappedParallelMathMLDOM;

import org.w3c.dom.Document;

/**
 * Some useful (but scary looking) methods for building up {@link CompoundValueWrapper}s
 * of various types.
 * <p>
 * This is useful for wrapping up existing values and also handy for testing.
 *
 * @author  David McKain
 * @version $Revision: 1999 $
 */
public final class WrapperUtilities {
    
    /**
     * Unravels an up-converted MathML document (as produced previously from either from raw
     * SnuggleTeX, ASCIIMathML or Maxima MathML output) and converts the result to a
     * {@link MathsContentValueWrapper}.
     * <p>
     * The caller should have checked that there were no errors in the process.
     */
    public static MathsContentOutputValueWrapper createFromUpconvertedMathMLDocument(final MathsContentSource source,
            final Document upConvertedMathMLDocument) {
        UnwrappedParallelMathMLDOM unwrappedDocument = MathMLUtilities.unwrapParallelMathMLDOM(upConvertedMathMLDocument.getDocumentElement());
        MathsContentOutputValueWrapper result = new MathsContentOutputValueWrapper();
        result.setSource(source);
        
        Document pMathMLDocument = MathMLUtilities.isolateFirstBranch(unwrappedDocument);
        result.setPMathML(MathMLUtilities.serializeDocument(pMathMLDocument));
        result.setPMathMLElement(pMathMLDocument.getDocumentElement());

        /* Extract up-converted information */
        Document cMathMLDocument = MathMLUtilities.isolateAnnotationXML(unwrappedDocument, MathMLUpConverter.CONTENT_MATHML_ANNOTATION_NAME);
        if (cMathMLDocument!=null) {
            result.setCMathML(MathMLUtilities.serializeDocument(cMathMLDocument));
        }
        result.setMaximaInput(unwrappedDocument.getTextAnnotations().get(MathMLUpConverter.MAXIMA_ANNOTATION_NAME));
        
        /* Extract any up-conversion failures */
        result.setUpconversionFailures(UpConversionUtilities.extractUpConversionFailures(upConvertedMathMLDocument));
        
        /* That's it! */
        return result;
    }
    
    //------------------------------------------------------------------------
    
    /**
     * Creates a {@link SingleValueWrapper} instance of the given type, representing a null
     * value.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type
     * @param resultClass Class specifying the required SingleValueWrapper type
     */
    public static <B, S extends SingleValueWrapper<B>>
    S createSingleValue(final Class<S> resultClass) {
        return instantiateValueWrapper(resultClass);
    }
    
    /**
     * Creates a {@link CompoundValueWrapper} instance of the given type, representing an empty
     * collection.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type for the elements in the collection
     * @param <C> required {@link CompoundValueWrapper} type.
     * @param resultClass Class specifying the required SingleValueWrapper type
     */
    public static <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>>
    C createCompoundValue(final Class<C> resultClass) {
        return instantiateValueWrapper(resultClass);
    }
    
    /**
     * Creates a {@link CompoundValueWrapper} instance of the given type, containing
     * the given (wrapped) items.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type for the elements in the collection
     * @param <C> required {@link CompoundValueWrapper} type.
     * @param resultClass Class specifying the required SingleValueWrapper type
     * @param itemValueWrappers items to add to the resulting collection.
     */
    public static <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>> 
    C createCompoundValue(final Class<C> resultClass, final Iterable<S> itemValueWrappers) {
        C result = createCompoundValue(resultClass);
        for (S valueWrapper : itemValueWrappers) {
            result.add(valueWrapper);
        }
        return result;
    }
    
    /**
     * Creates a {@link CompoundValueWrapper} instance of the given type, containing
     * the given (wrapped) items.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type for the elements in the collection
     * @param <C> required {@link CompoundValueWrapper} type.
     * @param resultClass Class specifying the required SingleValueWrapper type
     * @param itemValueWrappers items to add to the resulting collection.
     */
    public static <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>> 
    C createCompoundValue(final Class<C> resultClass, final S... itemValueWrappers) {
        C result = createCompoundValue(resultClass);
        for (S valueWrapper : itemValueWrappers) {
            result.add(valueWrapper);
        }
        return result;
    }
    
    
    /**
     * Creates a {@link CompoundValueWrapper} instance of the given type, containing
     * wrapped versions of the given raw items.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type for the elements in the collection
     * @param <C> required {@link CompoundValueWrapper} type.
     * @param resultWrapperClass Class specifying the required SingleValueWrapper type
     * @param itemValues items to add to the resulting collection.
     */
    public static <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>> 
    C createCompoundValue(final Class<C> resultWrapperClass, final Class<S> itemWrapperClass,
            final Iterable<B> itemValues) {
        C result = createCompoundValue(resultWrapperClass);
        for (B value : itemValues) {
            S item = instantiateValueWrapper(itemWrapperClass);
            item.setValue(value);
            result.add(item);
        }
        return result;
    }
    
    /**
     * Creates a {@link CompoundValueWrapper} instance of the given type, containing
     * wrapped versions of the given raw items.
     * 
     * @param <B> underlying baseType
     * @param <S> required {@link SingleValueWrapper} type for the elements in the collection
     * @param <C> required {@link CompoundValueWrapper} type.
     * @param resultClass Class specifying the required SingleValueWrapper type
     * @param itemValues items to add to the resulting collection.
     */
    public static <B, S extends SingleValueWrapper<B>, C extends CompoundValueWrapper<B,S>> 
    C createCompoundValue(final Class<C> resultClass, final Class<S> itemClass, B... itemValues) {
        C result = createCompoundValue(resultClass);
        for (B value : itemValues) {
            S item = instantiateValueWrapper(itemClass);
            item.setValue(value);
            result.add(item);
        }
        return result;
    }
    
    private static <V extends ValueWrapper> V instantiateValueWrapper(final Class<V> valueWrapperClass) {
        try {
            return valueWrapperClass.newInstance();
        }
        catch (Exception e) {
            throw new QTICASBridgeException("Unexpected Exception instantiating ValueWrapper of type "
                    + valueWrapperClass);
        }
    }


}
