/* $Id: MathsContentValueWrapper.java 1904 2009-02-11 17:31:27Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;

import org.w3c.dom.Element;

/**
 * Trivial wrapper representing a MathAssess MathsContent value.
 * <p>
 * Please check the JavaDoc to find out which fields are used when transferring
 * data into and out from the QTI/CAS Bridge layer.
 *
 * @author  David McKain
 * @version $Revision: 1904 $
 */
public final class MathsContentValueWrapper implements ValueWrapper {
    
    /**
     * Raw ASCIIMathInput, where applicable.
     * <p>
     * This SHOULD be filled in when passing values into the bridge that
     * were obtained from an interaction using ASCIIMathML, though the
     * data isn't actually used anywhere.
     * <p>
     * This will ALWAYS be null when returning data from the bridge.
     * 
     * FIXME: There's an argument for dropping this completely here as it's just
     * not used at all in the bridge!
     */
    private String asciiMathInput;
    
    /** 
     * (For debugging) Raw Presentation MathML output by Maxima. This is set
     * by {@link QTIMaximaSession} when pulling MathML out of Maxima. Feel free
     * to ignore and don't bother filling this in yourself when passing
     * {@link MathsContentValueWrapper} Objects "into" the bridge.
     */
    private String rawMaximaPMathML;
    
    /** 
     * Tidied up Presentation MathML.
     * <p>
     * You MUST fill this in when passing these wrappers into the bridge.
     * <p>
     * This will always be filled in when returning MathsContent from the bridge.
     */
    private Element pmathMLElement;
    
    /** Up-converted Content MathML.
     * <p>
     * You don't have to fill this in when passing these wrappers into the bridge as it's
     * not used.
     * <p>
     * this will always be filled in when returning MathsContent from the bridge.
     */
    private Element cmathMLElement;
    
    /** Up-converted Maxima input.
     * <p>
     * You MUST fill this in when passing these wrappers into the bridge.
     * <p>
     * This will always be filled in when returning MathsContent from the bridge.
     */
    private String maximaInput;
    
    public String getAsciiMathInput() {
        return asciiMathInput;
    }

    public void setAsciiMathInput(String asciiMathInput) {
        this.asciiMathInput = asciiMathInput;
    }
    
    
    public String getRawMaximaPMathML() {
        return rawMaximaPMathML;
    }
    
    public void setRawMaximaPMathML(String rawMaximaPMathML) {
        this.rawMaximaPMathML = rawMaximaPMathML;
    }


    public Element getPMathMLElement() {
        return pmathMLElement;
    }

    public void setPMathMLElement(Element pmathMLElement) {
        this.pmathMLElement = pmathMLElement;
    }

    
    public Element getCMathMLElement() {
        return cmathMLElement;
    }

    public void setCMathMLElement(Element cmathMLElement) {
        this.cmathMLElement = cmathMLElement;
    }

    
    public String getMaximaInput() {
        return maximaInput;
    }

    public void setMaximaInput(String maximaInput) {
        this.maximaInput = maximaInput;
    }


    public ValueType getType() {
        return ValueType.MATHS_CONTENT;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName()
            + "(asciiMathInput=" + asciiMathInput
            + ",rawMaximaPMathML=" + rawMaximaPMathML
            + ",pmathMLElement=" + (pmathMLElement!=null ? MathMLUtilities.serializeElement(pmathMLElement) : null)
            + ",cmathMLElement=" + (cmathMLElement!=null ? MathMLUtilities.serializeElement(cmathMLElement) : null)
            + ",maximaInput=" + maximaInput
            + ")";
    }
}
