/* $Id: BadQTICASCodeException.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Represents a failure caused by bad CAS code in the QTI, which should ultimately
 * be fixed by the QTI author.
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public final class BadQTICASCodeException extends Exception {
    
    private static final long serialVersionUID = 5940754810506417594L;

    public BadQTICASCodeException() {
        super();
    }

    public BadQTICASCodeException(String message, Throwable cause) {
        super(message, cause);
    }

    public BadQTICASCodeException(String message) {
        super(message);
    }

    public BadQTICASCodeException(Throwable cause) {
        super(cause);
    }
}
