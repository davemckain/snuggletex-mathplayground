/* $Id: ASCIIMathMLHelperExample.java 1977 2009-03-10 15:30:31Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.qticasbridge.ASCIIMathMLHelper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;

import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;

/**
 * Demonstrates the {@link ASCIIMathMLHelper} class on some sample ASCIIMath input.
 *
 * @author  David McKain
 * @version $Revision: 1977 $
 */
public final class ASCIIMathMLHelperExample {
    
    public static void main(String[] args) throws Exception {
        /* OK. Let's suppose the student entered '10x-6' into the box. */
        String asciiMathInput = "10x-6";
        
        /* We'd use some JavaScript to extract the following raw PresentationMathML from ASCIIMath: */
        String rawASCIIMathMLOutput = "<math title=\" 10x-6 \" xmlns=\"http://www.w3.org/1998/Math/MathML\">"
            + "  <mstyle mathcolor=\"blue\" fontfamily=\"serif\" displaystyle=\"true\">\n"
            + "    <mn>10</mn>\n"
            + "    <mi>x</mi>\n" 
            + "    <mo>-</mo>\n"
            + "    <mn>6</mn>\n"
            + "  </mstyle>\n"
            + "</math>";
        
        /* Now we use the helper to populate a MathsContentValueWrapper */
        ASCIIMathMLHelper asciiMathMLHelper = new ASCIIMathMLHelper(new DefaultStylesheetCache());
        MathsContentValueWrapper result = asciiMathMLHelper.createMathsContentFromASCIIMath(asciiMathInput, rawASCIIMathMLOutput);
        
        /* Now just dump out the result */
        System.out.println("Got result: " + result);
    }
}
