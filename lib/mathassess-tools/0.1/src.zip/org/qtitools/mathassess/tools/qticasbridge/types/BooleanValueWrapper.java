/* $Id: BooleanValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper representing a QTI boolean value.
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class BooleanValueWrapper extends SingleValueWrapper<Boolean> {
    
    public BooleanValueWrapper() {
        this(false);
    }
    
    public BooleanValueWrapper(final Boolean value) {
        super(value);
    }
    
    public BooleanValueWrapper(final boolean value) {
        this(Boolean.valueOf(value));
    }
    
    @Override
    public ValueBaseType getBaseType() {
        return ValueBaseType.BOOLEAN;
    }
}
