/* $Id: SpecUnimplementedException.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Hopefully temporary Exception thrown if something is attempted that has been
 * defined in the QTI/CAS bridge spec but has not yet been unimplemented.
 * 
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public class SpecUnimplementedException extends QTICASBridgeException {

    private static final long serialVersionUID = 3890296776080082123L;

    public SpecUnimplementedException() {
        super();
    }

    public SpecUnimplementedException(String message, Throwable cause) {
        super(message, cause);
    }

    public SpecUnimplementedException(String message) {
        super(message);
    }

    public SpecUnimplementedException(Throwable cause) {
        super(cause);
    }
}
