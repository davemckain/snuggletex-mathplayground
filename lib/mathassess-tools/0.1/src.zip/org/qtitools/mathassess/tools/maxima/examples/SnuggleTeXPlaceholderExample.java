/* $Id: SnuggleTeXPlaceholderExample.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.authoring.AuthoringGlobals;

import uk.ac.ed.ph.snuggletex.DOMOutputOptions;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConvertingPostProcessor;

import java.io.IOException;

/**
 * Trivial example demonstrating the special <tt>\\qv</tt> macro being used with SnuggleTeX.
 * <p>
 * (Note that this doesn't perform any subsitutions...)
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class SnuggleTeXPlaceholderExample {
    
    public static void main(String[] args) throws IOException {
        /* We need to register the special \qv command with the SnuggleEngine before using it */
        SnuggleEngine engine = new SnuggleEngine();
        engine.registerDefinitions(AuthoringGlobals.getSnuggleTeXDefinitionMap());
        
        /* Now we do an example conversion */
        SnuggleSession session = engine.createSession();
        DOMOutputOptions outputOptions = new DOMOutputOptions();
        outputOptions.setDOMPostProcessor(new UpConvertingPostProcessor());
        session.parseInput(new SnuggleInput("$ \\qv{mAns} + 5 $"));
        
        /* We'll just dump the result out */
        System.out.println("SnuggleTeX conversion resulted in " + session.buildXMLString());
    }
}
