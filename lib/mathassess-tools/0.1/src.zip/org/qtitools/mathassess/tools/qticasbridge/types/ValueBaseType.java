/* $Id: ValueBaseType.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Encapsulates the different QTI types that will be passed
 * to/from the CAS system.
 * 
 * @see ValueWrapper
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public enum ValueBaseType {
    
    STRING,
    BOOLEAN,
    INTEGER,
    FLOAT,
    POINT,
    
    ;

}
