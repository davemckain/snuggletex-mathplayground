/* $Id: VariableWrapper.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Wrapper representing a QTI variable.
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public final class VariableWrapper implements ValueOrVariableWrapper {
    
    /** Identifier for the underlying QTI variable (also used as Maxima variable name) */
    private final String identifier;
    
    public VariableWrapper(String identifier) {
        this.identifier = identifier;
    }
    
    public String getIdentifier() {
        return identifier;
    }
}
