/* $Id: PointOrderedValueWrapper.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Represents a value of cardinality 'ordered' having point base type.
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class PointOrderedValueWrapper extends OrderedValueWrapper<Integer[], PointValueWrapper> {

    private static final long serialVersionUID = 6084887627999436539L;

    public Class<PointValueWrapper> getItemClass() {
        return PointValueWrapper.class;
    }
}
