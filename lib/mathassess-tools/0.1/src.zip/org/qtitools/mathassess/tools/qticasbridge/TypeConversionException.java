/* $Id: TypeConversionException.java 1956 2009-03-05 14:00:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

import org.qtitools.mathassess.tools.qticasbridge.types.ValueWrapper;

/**
 * This Exception is thrown when attempting to extract and convert a Maxima
 * output into a QTI value having an incompatible type.
 *
 * @author  David McKain
 * @version $Revision: 1956 $
 */
public final class TypeConversionException extends QTICASAuthoringException {
    
    private static final long serialVersionUID = 5940754810506417594L;
    
    private final String maximaInput;
    private final String maximaOutput;
    private final Class<? extends ValueWrapper> badTypeClass;

    public TypeConversionException(final String maximaInput, final String maximaOutput,
            final Class<? extends ValueWrapper> badTypeClass) {
        super("Could not convert Maxima result to type " + badTypeClass);
        this.maximaInput = maximaInput;
        this.maximaOutput = maximaOutput;
        this.badTypeClass = badTypeClass;
    }
    
    public String getMaximaInput() {
        return maximaInput;
    }
    
    public String getMaximaOutput() {
        return maximaOutput;
    }

    public Class< ? extends ValueWrapper> getBadTypeClass() {
        return badTypeClass;
    }
}
