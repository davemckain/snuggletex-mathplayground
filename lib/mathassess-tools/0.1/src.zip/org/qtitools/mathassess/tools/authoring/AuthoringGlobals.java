/* $Id: AuthoringGlobals.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.authoring;

import uk.ac.ed.ph.snuggletex.definitions.DefinitionMap;
import uk.ac.ed.ph.snuggletex.definitions.Globals;

/**
 * Some authoring-related MathAssess globals.
 *
 * @author  David McKain
 * @version $Revision: 1902 $
 */
public final class AuthoringGlobals {
    
    /**
     * (Temporary) flag to denote whether we will be encoding <tt>\\qv</tt> variables
     * inside MathML elements as attributes, or whether as element content.
     * <p>
     * Exactly which route we take here is to be discussed...
     * <p>
     * We'll keep the default option of not using attributes for the time being, as it's 
     * more compatible with Sue's demo XML.
     */
    public static boolean ENCODE_PLACEHOLDER_AS_ATTRIBUTE = false;
    
    /** MathAssess Namespace */
    public static final String MATHASSESS_NS = "http://mathassess.qtitools.org/xsd/mathassess";
    
    /** Prefix to use for MathAssess-related stuff inside MathML elements */
    public static final String MATHASSESS_PREFIX = "ma";
    
    /** Name of the <tt>mi</tt> attribute that will specify the identifier of the underlying QTI variable */
    public static final String QV_ATTRIBUTE_NAME = "varIdentifier";
    
    /**
     * SnuggleTeX {@link DefinitionMap} providing the functionality required to implement
     * any extra MathAssess authoring commands.
     */
    private static final DefinitionMap snuggleTeXDefinitionMap;
    
    static {
        snuggleTeXDefinitionMap = new DefinitionMap();
        snuggleTeXDefinitionMap.addComplexCommandSameArgMode("qv", false, 1, Globals.MATH_MODE_ONLY, 
                new QvHandler(), null);
    }
    
    public static final DefinitionMap getSnuggleTeXDefinitionMap() {
        return snuggleTeXDefinitionMap;
    }
}
