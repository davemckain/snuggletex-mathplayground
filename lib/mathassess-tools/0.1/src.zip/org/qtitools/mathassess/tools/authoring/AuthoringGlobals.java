/* $Id: AuthoringGlobals.java 1955 2009-03-04 17:13:58Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.authoring;

import uk.ac.ed.ph.snuggletex.definitions.DefinitionMap;
import uk.ac.ed.ph.snuggletex.definitions.Globals;

/**
 * Some authoring-related MathAssess globals.
 *
 * @author  David McKain
 * @version $Revision: 1955 $
 */
public final class AuthoringGlobals {
    
    /**
     * SnuggleTeX {@link DefinitionMap} providing the functionality required to implement
     * any extra MathAssess authoring commands.
     */
    private static final DefinitionMap snuggleTeXDefinitionMap;
    
    static {
        snuggleTeXDefinitionMap = new DefinitionMap();
        snuggleTeXDefinitionMap.addComplexCommandSameArgMode("qv", false, 1, Globals.MATH_MODE_ONLY, 
                new QvHandler(), null);
    }
    
    public static final DefinitionMap getSnuggleTeXDefinitionMap() {
        return snuggleTeXDefinitionMap;
    }
}
