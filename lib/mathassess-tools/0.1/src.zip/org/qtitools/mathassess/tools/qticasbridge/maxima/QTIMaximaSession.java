/* $Id: QTIMaximaSession.java 1999 2009-03-15 22:29:41Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.maxima;

import org.qtitools.mathassess.tools.maxima.MaximaTimeoutException;
import org.qtitools.mathassess.tools.maxima.RawMaximaSession;
import org.qtitools.mathassess.tools.maxima.upconversion.MaximaMathMLUpConverter;
import org.qtitools.mathassess.tools.qticasbridge.BadQTICASCodeException;
import org.qtitools.mathassess.tools.qticasbridge.MathsContentTooComplexException;
import org.qtitools.mathassess.tools.qticasbridge.QTICASBridgeException;
import org.qtitools.mathassess.tools.qticasbridge.TypeConversionException;
import org.qtitools.mathassess.tools.qticasbridge.types.BooleanValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentOutputValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentSource;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.ValueOrVariableWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.ValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.WrapperUtilities;
import org.qtitools.mathassess.tools.utilities.ConstraintUtilities;

import uk.ac.ed.ph.snuggletex.SnuggleEngine.DefaultStylesheetCache;
import uk.ac.ed.ph.snuggletex.definitions.Globals;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConversionFailure;
import uk.ac.ed.ph.snuggletex.utilities.StylesheetCache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Main entry point for performing MathAssess QTI-related interactions with Maxima.
 * 
 * <h2>Usage Notes</h2>
 * <ul>
 *   <li>
 *     An instance of this class should only be used by one Thread at a time but is serially
 *     reusable.
 *   </li>
 *   <li>
 *     Call {@link #open()} to start up a fresh Maxima session.
 *   </li>
 *   <li>
 *     Each method called that interacts with Maxima will be done in current Maxima session,
 *     so will have the (usually desired) side-effect of changing Maxima's state.
 *   </li>
 *   <li>
 *     Call {@link #close()} to close the underlying Maxima session.
 *   </li>
 *   <li>
 *     For examples, see the examples package or the test suite.
 *   </li>
 * </ul>
 * 
 * FIXME: Add constraints from the spec on which values can be passed to CasCompare and CasCondition
 * FIXME: Need to think about randomisation seeds...
 * 
 * @author  David McKain
 * @version $Revision: 1999 $
 */
public final class QTIMaximaSession {

    /** Maxima code for the <tt>equal</tt> action in <tt>CasCompare</tt> */
    public static final String MAXIMA_EQUAL_CODE = "is(equal($1=$2))";
    
    /** Maxima code for the <tt>syntequal<tt> action in <tt>CasCompare</tt> */
    public static final String MAXIMA_SYNTEQUAL_CODE = "is($1=$2)";
    
    /** Underlying Raw Maxima Session */
    private final RawMaximaSession rawMaximaSession;
    
    /** Helper to up-convert Maxima MathML output */
    private final MaximaMathMLUpConverter maximaMathMLUpconverter;
    
    /** Maxima Data Binding helper */
    private final MaximaDataBinder maximaDataBinder;
    
    public QTIMaximaSession() {
        this(new DefaultStylesheetCache());
    }
    
    public QTIMaximaSession(StylesheetCache stylesheetCache) {
        this.rawMaximaSession = new RawMaximaSession();
        this.maximaMathMLUpconverter = new MaximaMathMLUpConverter(stylesheetCache);
        this.maximaDataBinder = new MaximaDataBinder();
    }
    
    //------------------------------------------------
    // Session lifecycle methods (delegates to underlying RawMaximaSession)
    
    public void open() throws MaximaTimeoutException {
        /* Open up the underlying session */
        rawMaximaSession.open();
        
        /* Load the MathML module */
        rawMaximaSession.executeRaw("load(mathml)$");
        
        /* Turn off simplification by default. We'll turn on temporarily if/when needed */
        rawMaximaSession.executeRaw("simp:false$");
    }
    
    public void close() {
        rawMaximaSession.close();
    }
    
    //------------------------------------------------
    // General and rather low level methods for getting Maxima to evaluate an expression and return
    // results in a parseable form.
    
    /**
     * Convenience method to evaluate the given Maxima expression, which is assumed to be
     * a single expression of the form "expr" or "expr;", using <tt>grind()</tt>
     * to format the output, returning a tidied (but unparsed) version of the resulting output.
     * 
     * @param maximaExpression Maxima expression to evaluate, which can be of the form
     *   "expr" or "expr;".
     * @return grind output, trimmed with the trailing '$' character removed.
     * 
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the output from grind() did not have the expected
     *   format, most likely indicating bad input.
     * 
     * @see #executeGrindOutput(String, Class)
     */
    public String executeGrindOutput(final String maximaExpression)
            throws MaximaTimeoutException, BadQTICASCodeException {
        ConstraintUtilities.ensureNotNull(maximaExpression, "Maxima expression");
        
        /* Strip off any terminator, if provided */
        String withoutTerminator = stripTrailingTerminator(maximaExpression);
        if (withoutTerminator.length()==0) {
            /* Exit now as grind() doesn't behave as expected here! */
            return "";
        }
        
        /* First of all, we'll check whether the variable is actually defined by asking Maxima
         * to return it. We will use the "grind(var)$" form as me may end up picking this
         * apart to extract the actual value later. 
         * 
         * (Also note that grind() is strange in that it echoes to stdout, rather than
         * returning a value.)
         */
        String maximaInput = "grind(" + withoutTerminator + ")$";
        String rawLineOutput = rawMaximaSession.executeRaw(maximaInput).trim();
        if (!rawLineOutput.endsWith("$")) {
            throw new BadQTICASCodeException(maximaInput, "Output from grind() did not end with '$'");
        }
        return rawLineOutput.substring(0, rawLineOutput.length() - 1);
    }
    
    /**
     * Convenience method to evaluate the given Maxima expression, which is assumed to be
     * a single expression of the form "expr" or "expr;", using <tt>grind()</tt>
     * to format the output and parsing the output to fit the given resultClass.
     * 
     * @param maximaExpression Maxima expression to evaluate, which can be of the form
     *   "expr" or "expr;".
     * @param resultClass Class corresponding to the desired type of {@link ValueWrapper} to return
     * @param <V> desired type of {@link ValueWrapper} to return.
     * 
     * @return Maxima output, parsed as a value of the given type, or null if the value
     *   is not of the given type.
     *   
     * @throws MaximaTimeoutException
     * @throws BadQTICASCodeException if the output from grind() could not be parsed,
     *   most likely indicating bad input.
     * @throws TypeConversionException if the output from grind() could not be converted
     *   into the desired return type.
     * 
     * @see #executeGrindOutput(String)
     */
    public <V extends ValueWrapper> V executeGrindOutput(final String maximaExpression,
            final Class<V> resultClass)
            throws MaximaTimeoutException, BadQTICASCodeException, TypeConversionException {
        String rawGrindOutput = executeGrindOutput(maximaExpression);
        V result = maximaDataBinder.parseGrindOutput(rawGrindOutput, resultClass);
        if (result==null) {
            throw new TypeConversionException(maximaExpression, rawGrindOutput, resultClass);
        }
        return result;
    }
    
    private String stripTrailingTerminator(final String maximaInput) {
        if (maximaInput.endsWith(";") || maximaInput.endsWith("$")) {
            return maximaInput.substring(0, maximaInput.length() - 1);
        }
        return maximaInput;
    }
    
    /**
     * Convenience method to evaluate the given Maxima expression, which is assumed to be
     * a single expression of the form "expr" or "expr;", outputting the result as MathML
     * which is then up-converted and represented as a {@link MathsContentOutputValueWrapper}.
     * <p>
     * The implementation converts this to "mathml(expr);" and returns the result as a
     * {@link MathsContentOutputValueWrapper}.
     * 
     * @return MathsContentOutputValueWrapper representing the given Maxima expression and
     *   the results of up-conversion on it.
     * 
     * @throws MathsContentTooComplexException if the output from Maxima could not be
     *   up-converted, presumably because it is too complex.
     * @throws MaximaTimeoutException
     */
    public MathsContentOutputValueWrapper executeMathOutput(final String maximaExpression)
            throws MaximaTimeoutException, MathsContentTooComplexException {
        ConstraintUtilities.ensureNotNull(maximaExpression, "Maxima expression");
        
        /* Do MathML output and up-convert */
        MathsContentOutputValueWrapper result = doExecuteMathOutput(maximaExpression);
        
        /* Fail fast if any up-conversion failures were found */
        List<UpConversionFailure> upConversionFailures = result.getUpconversionFailures();
        if (upConversionFailures!=null && !upConversionFailures.isEmpty()) {
            throw new MathsContentTooComplexException(result);
        }
        return result;
    }
    
    private MathsContentOutputValueWrapper doExecuteMathOutput(final String maximaExpression)
            throws MaximaTimeoutException {
        /* Chop off any trailing terminator */
        String resultingExpression = stripTrailingTerminator(maximaExpression);
        
        /* Convert to "mathml(expr);" format */
        resultingExpression = "mathml(" + resultingExpression + ");";
        
        /* Then execute and up-convert the results */
        String rawMaximaMathMLOutput = rawMaximaSession.executeRaw(resultingExpression);
        
        /* Up-convert the raw MathML and create appropriate wrapper */
        Document upconvertedDocument = maximaMathMLUpconverter.upconvertRawMaximaMathML(rawMaximaMathMLOutput);
        
        /* Create appropriate wrapper */
        return  WrapperUtilities.createFromUpconvertedMathMLDocument(MathsContentSource.CAS_OUTPUT, upconvertedDocument);
    }
     
    //------------------------------------------------
    // Methods for passing and extracting variables between the QTI layer and Maxima
    
    /**
     * Assigns the given {@link ValueWrapper} to the given QTI variable within Maxima.
     * <p>
     * If the {@link ValueWrapper} is null or encapsulates a null value, then the corresponding
     * Maxima variable is cleared.
     * 
     * @param variableIdentifier QTI variable identifier, which must not be null
     * @param valueWrapper representing the QTI value of the variable.
     * 
     * @throws IllegalArgumentException if the given value is null, represents a null value or
     *   is a {@link MathsContentValueWrapper} with a missing maximaInput field.
     */
    public void passQTIVariableToMaxima(final String variableIdentifier, final ValueWrapper valueWrapper) {
        checkVariableIdentifier(variableIdentifier);
        if (valueWrapper==null || valueWrapper.isNull()) {
            /* Nullify variable using kill() */
            try {
                rawMaximaSession.executeRaw("kill(" + variableIdentifier  + ")$");
            }
            catch (MaximaTimeoutException e) {
                /* This shouldn't happen here! */
                throw new QTICASBridgeException("Unexpected timeout while killing Maxima variable "
                        + variableIdentifier, e);
            }            
        }
        else {
            /* Convert the QTI value to an appropriate Maxima expression */
            String maximaValue = maximaDataBinder.toMaximaExpression(valueWrapper);
            
            /* Then do the appropriate Maxima call */
            try {
                rawMaximaSession.executeRaw(variableIdentifier + ": " + maximaValue + "$");
            }
            catch (MaximaTimeoutException e) {
                /* This shouldn't happen here! */
                throw new QTICASBridgeException("Unexpected timeout when setting Maxima variable "
                        + variableIdentifier + " to value " + maximaValue, e);
            }
        }
    }
    
    /**
     * Asks Maxima to return the value of the variable with the given identifier in a form
     * matching the given resultClass.
     * <p>
     * Note that it's legal to ask Maxima to return the value of any variable as a
     * {@link MathsContentOutputValueWrapper}, even if it wasn't defined that way at first.
     * The converse isn't necessarily trough, though, so think carefully whether any
     * attempted type conversions are legal.
     * 
     * @param variableIdentifier code to be executed returning a single value of the given type
     * @param resultClass Class specifying the required return type
     * @param <V> required return type
     * 
     * @return wrapper encapsulating the resulting QTI value of the given variable, or null
     *   if it isn't defined.
     *   
     * @throws TypeConversionException if the given variable could not be represented using
     *   the specified resultClass.
     * @throws MathsContentTooComplexException if the output from Maxima could not be
     *   up-converted, presumably because it is too complex.
     * @throws QTICASBridgeException if a timeout occurs.
     */
    @SuppressWarnings("unchecked")
    public <V extends ValueWrapper> V queryMaximaVariable(final String variableIdentifier,
            final Class<V> resultClass)
            throws TypeConversionException, MathsContentTooComplexException {
        checkVariableIdentifier(variableIdentifier);
        ConstraintUtilities.ensureNotNull(resultClass, "resultClass");
        try {
            /* First of all, we'll check whether the variable is actually defined by asking Maxima
             * to return it. We will use the "grind(var)$" form as me may end up picking this
             * apart to parse the actual value later. 
             */
            String grindOutput;
            try {
                grindOutput = executeGrindOutput(variableIdentifier);
            }
            catch (BadQTICASCodeException e) {
                throw new QTICASBridgeException("Unexpected failure to parse grind() output", e);
            }
            
            /* If we got the variable name back, then it wasn't defined */
            if (variableIdentifier.equals(grindOutput)) {
                /* Variable not defined */
                return null;
            }
                
            /* What we do next depends on whether we are returning a MathsContent variable or not. */
            V result;
            if (MathsContentValueWrapper.class.isAssignableFrom(resultClass)) {
                /* We ask Maxima again, this time returning MathML */
                result = (V) executeMathOutput(variableIdentifier);
            }
            else {
                /* We just parse the grind() output */
                result = maximaDataBinder.parseGrindOutput(grindOutput, resultClass);
                if (result==null) {
                    throw new TypeConversionException(variableIdentifier, grindOutput, resultClass);
                }
            }
            return result;
        }
        catch (MaximaTimeoutException e) {
            throw new QTICASBridgeException("Unexpected timeout occurred while extracting the value of variable "
                    + variableIdentifier, e);
        }
    }
    
    /**
     * Helper method to validate a QTI variable identifier to ensure it matches the restrictions
     * outlined in the spec. (This is designed to allow it to be used as a Maxima variable as-is.)
     * 
     * @param variableIdentifier QTI variable identifier
     * 
     * @throws IllegalArgumentException if the given variableIdentifier is not compatible with
     *   the allowed production rules
     */
    private void checkVariableIdentifier(final String variableIdentifier) {
        ConstraintUtilities.ensureNotNull(variableIdentifier, "variableIdentifier");
      
        /* Ensure that the name matches NCName intersected with alphanumeric */
        if (!Pattern.matches("[a-zA-Z][a-zA-Z0-9]*", variableIdentifier)) {
            throw new IllegalArgumentException("variableIdentifier is not a suitably restricted NCName as defined in the QTI/CAS spec");
        }
    }
    
    //------------------------------------------------
    // Bridge methods for custom QTI elements
    
    /**
     * Performs the CAS work for <tt>ScriptRule</tt>.
     * 
     * @param maximaCode maxima code to be executed
     * 
     * @throws MaximaTimeoutException
     */
    public void executeScriptRule(final String maximaCode) throws MaximaTimeoutException {
        ConstraintUtilities.ensureNotNull(maximaCode, "maximaCode");
        rawMaximaSession.executeRaw(maximaCode);
    }
    
    /**
     * Performs the CAS work for <tt>CasProcess</tt>
     * 
     * @param maximaCode code to be executed returning a single value of the given type
     * @param resultClass Class specifying required return type
     * @param <V> required return type
     * 
     * @return wrapper encapsulating the resulting QTI value
     * 
     * @throws BadQTICASCodeException if the given Maxima code did not produce a result which
     *   could be parsed.
     * @throws TypeConversionException if the output from Maxima could not be represented using
     *   the specified resultClass.
     * @throws MathsContentTooComplexException if the output from Maxima could not be
     *   up-converted, presumably because it is too complex.
     * @throws MaximaTimeoutException
     */
    @SuppressWarnings("unchecked")
    public <V extends ValueWrapper> V executeCasProcess(final String maximaCode, final Class<V> resultClass)
            throws TypeConversionException, MaximaTimeoutException,
            BadQTICASCodeException, MathsContentTooComplexException {
        ConstraintUtilities.ensureNotNull(maximaCode, "maximaCode");
        ConstraintUtilities.ensureNotNull(resultClass, "resultClass");
        
        /* What we do here depends on whether we are returning a MathsContent variable or not. */
        V result;
        if (MathsContentValueWrapper.class.isAssignableFrom(resultClass)) {
            /* Get result as MathML */
            result = (V) executeMathOutput(maximaCode);
        }
        else {
            /* Get result using grind() */
            result = executeGrindOutput(maximaCode, resultClass);
        }
        return result;
    }

    /**
     * Performs the CAS work for <tt>CasCompare</tt> when authored with an explicit Maxima
     * code expression.
     * <p>
     * NOTE: The code passed here should <strong>NOT</strong> have a leading "casresult:"
     * string in it!
     * 
     * @param comparisonCode Maxima code that does the comparison work, expected to return
     *   a boolean value.
     * @param arg1 encapsulates the first value/variable to be compared
     * @param arg2 encapsulates the second value/variable to be compared
     * 
     * @return true or false
     * 
     * @throws IllegalArgumentException if the given code is null, or if any of the arguments
     *   is null or represents a null value or is a {@link MathsContentValueWrapper}
     *   with a missing maximaInput field.
     * @throws BadQTICASCodeException if the resulting Maxima call does not
     *   return either true or false
     * @throws MaximaTimeoutException
     */
    public boolean executeCasCompare(final String comparisonCode, final boolean simplify,
            final ValueOrVariableWrapper arg1, final ValueOrVariableWrapper arg2)
            throws MaximaTimeoutException, BadQTICASCodeException {
        return executeCasCondition(comparisonCode, simplify, arg1, arg2);
    }
    
    /**
     * Performs the CAS work for <tt>CasCondition</tt>
     * 
     * @param comparisonCode Maxima code that does the comparison work, expected to return
     *   a boolean value.
     * @param arguments array of arguments to be substituted into the Maxima code
     * 
     * @return true or false as reported by Maxima evaluating the given condition
     * 
     * @throws IllegalArgumentException if the given code is null, or if any of the arguments
     *   is null or represents a null value or is a {@link MathsContentValueWrapper}
     *   with a missing maximaInput field.
     * @throws BadQTICASCodeException if the resulting Maxima call does not
     *   return either true or false
     * @throws MaximaTimeoutException
     */
    public boolean executeCasCondition(final String comparisonCode, final boolean simplify,
            final ValueOrVariableWrapper... arguments)
            throws MaximaTimeoutException, BadQTICASCodeException {
        ConstraintUtilities.ensureNotNull(comparisonCode, "comparisonCode");
        /* Get maxima forms of the input values and perform substitutions */
        
        String maximaInput = comparisonCode;
        String searchRegexp, replacement;
        for (int i=0; i<arguments.length; i++) {
            ConstraintUtilities.ensureNotNull(arguments[i], "argument #" + (i+1));
            /* Using negative look-behind to allow things like $$ */
            searchRegexp = "(?<!\\$)\\$" + (i+1);
            
            /* Create replacement, adding brackets for safety and remembering to
             * escape any '$' in them */
            replacement = "(" + maximaDataBinder.toMaximaExpression(arguments[i]) + ")";
            replacement = replacement.replaceAll("[\\$\\\\]", "\\\\\\$");
            
            /* Perform search and replace */
            maximaInput = maximaInput.replaceAll(searchRegexp, replacement);
        }
        
        /* Replace any '$$' with literal '$' signs */
        maximaInput = maximaInput.replace("$$", "$");
        
        /* Now execute the appropriate call as a grind(), book-ended by code to temporarily
         * turn on simplification, if required.
         */
        BooleanValueWrapper compareResult;
        if (simplify) {
            /* Temporarily turn on simplification */
            rawMaximaSession.executeRaw("simp:true$");
        }
        try {
            compareResult = executeGrindOutput(maximaInput, BooleanValueWrapper.class);
        }
        catch (TypeConversionException e) {
            throw new BadQTICASCodeException(maximaInput, "Maxima call '" + maximaInput + "' did not return a boolean");
        }
        finally {
            if (simplify) {
                rawMaximaSession.executeRaw("simp:false$");
            }
        }
        return compareResult.getValue().booleanValue();
    }
    
    //------------------------------------------------
    // Substitution of sub-expressions in MathML

    /**
     * Traverses through the DOM tree of the given MathML <tt>math</tt> element, substituting
     * any <tt>mi</tt> elements corresponding to Maxima values of the same name with their
     * values (as MathML fragments).
     * 
     * @throws QTICASBridgeException if a problem occurred converting one of the variables to MathML
     * @throws MaximaTimeoutException
     */
    public void substituteVariables(Element rawMathMLElement)
            throws MaximaTimeoutException, QTICASBridgeException {
        ConstraintUtilities.ensureNotNull(rawMathMLElement, "MathML Element");
        /* We'll create a little hash to store variable lookups as we traverse the <math/>
         * element just in case we have the same variable more than once. This will save
         * having to make extra calls.
         */
        Map<String,MathsContentOutputValueWrapper> valuesCache = new HashMap<String, MathsContentOutputValueWrapper>();
        
        /* Now walk the <math/> XML tree making substitutions as required, grafting into the tree */
        try {
            doSubstituteVariables(rawMathMLElement, valuesCache);
        }
        catch (TypeConversionException e) {
            /* This shouldn't happen as conversion to MathsContent should always succeed! */
            throw new QTICASBridgeException("Did not expect to get a TypeConversionException during variable substitutions!");
        }
    }
    
    private void doSubstituteVariables(Element mathMLElement, Map<String,MathsContentOutputValueWrapper> valuesCache)
            throws MaximaTimeoutException, BadQTICASCodeException, TypeConversionException {
        /* Search child elements */
        NodeList childNodes = mathMLElement.getChildNodes();
        Node childNode;
        Element childElement;
        for (int i=0, size=childNodes.getLength(); i<size; i++) {
            childNode = childNodes.item(i);
            if (childNode.getNodeType()==Node.ELEMENT_NODE) {
                childElement = (Element) childNode;
                if (childElement.getLocalName().equals("mi")
                        && childElement.getNamespaceURI().equals(Globals.MATHML_NAMESPACE)) {
                    doHandleMiElement(childElement, valuesCache);
                }
                else {
                    /* Continue recursively.
                     * TODO: Should we avoid a possible stack overflow by flattening this out?
                     */
                    doSubstituteVariables(childElement, valuesCache);
                }
            }
        }
    }
    
    private void doHandleMiElement(Element miElement, Map<String,MathsContentOutputValueWrapper> valuesCache)
            throws TypeConversionException {
        /* Extract text content and see if it's a variable */
        StringBuilder contentBuilder = new StringBuilder();
        NodeList contentList = miElement.getChildNodes();
        for (int i=0, size=contentList.getLength(); i<size; i++) {
            contentBuilder.append(contentList.item(i).getNodeValue());
        }
        String varIdentifier = contentBuilder.toString();
        if (varIdentifier.length()>0) {
            MathsContentOutputValueWrapper mathValue = doExtractValue(varIdentifier, valuesCache);
            if (mathValue!=null) {
                /* It's defined in Maxima, so make the subs */
                doSubstituteVariableValue(miElement, mathValue);
            }
        }
    }
    
    private MathsContentOutputValueWrapper doExtractValue(final String varIdentifier,
            Map<String,MathsContentOutputValueWrapper> valuesCache)
            throws TypeConversionException {
        /* Note that we're caching 'null' lookups here */
        MathsContentOutputValueWrapper result = null;
        if (valuesCache.containsKey(varIdentifier)) {
            result = valuesCache.get(varIdentifier);
        }
        else {
            /* Ask Maxima for the value of the variable, but don't fail if up-conversion fails
             * as all we're going to do is interpolate the resulting PMathML.
             */
            try {
                result = doExecuteMathOutput(varIdentifier);
            }
            catch (MaximaTimeoutException e) {
                throw new QTICASBridgeException("Unexpected timeout extracting MathML value of variable " + varIdentifier);
            }
            valuesCache.put(varIdentifier, result);
        }
        return result;
    }
    
    private void doSubstituteVariableValue(Element miElement, final MathsContentOutputValueWrapper value) {
        Node parentNode = miElement.getParentNode();
        
        /* Need to adopt a clone of the (single) child of the enclosing <math> element in the isolated PMathML Element */
        Node pmathContent = value.getPMathMLElement().getChildNodes().item(0);
        Node pmathContentCloned = pmathContent.cloneNode(true);
        Node importedNode = parentNode.getOwnerDocument().adoptNode(pmathContentCloned);
        
        /* Replace <mi/> element with this value */
        parentNode.replaceChild(importedNode, miElement);
    }
}
