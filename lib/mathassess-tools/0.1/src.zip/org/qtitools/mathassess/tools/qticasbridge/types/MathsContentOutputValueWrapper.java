/* $Id: MathsContentOutputValueWrapper.java 1999 2009-03-15 22:29:41Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConversionFailure;

import java.util.List;

import org.w3c.dom.Element;

/**
 * Extension of {@link MathsContentValueWrapper} that includes some other bits and pieces
 * of "internal" information that you are free to ignore if you want!
 * <p>
 * You will generally get one of these as an "output" from the QTI/CAS layer. When passing
 * values "into" the QTI/CAS layer, you only need to pass a {@link MathsContentValueWrapper}.
 * 
 * @see WrapperUtilities
 *
 * @author  David McKain
 * @version $Revision: 1999 $
 */
public final class MathsContentOutputValueWrapper extends MathsContentValueWrapper {
    
    /** Indicates where the MathsContent in this wrapper came from. */
    private MathsContentSource source;
    
    /** 
     * Raw Presentation MathML before the up-conversion process is applied to it.
     * This may be useful for debugging.
     */
    private String rawPMathML;
    
    /**
     * Up-converted PMathML, as a DOM {@link Element} for convenience when performing substitutions.
     */
    private Element pMathMLElement;

    /**
     * Details of any up-conversion failures, null or empty if none occurred.
     */
    private List<UpConversionFailure> upconversionFailures;

    public MathsContentSource getSource() {
        return source;
    }
    
    public void setSource(MathsContentSource source) {
        this.source = source;
    }
    

    public String getRawPMathML() {
        return rawPMathML;
    }
    
    public void setRawPMathML(String rawPMathML) {
        this.rawPMathML = rawPMathML;
    }


    public Element getPMathMLElement() {
        return pMathMLElement;
    }
    
    public void setPMathMLElement(Element mathMLElement) {
        pMathMLElement = mathMLElement;
    }
    
    
    public List<UpConversionFailure> getUpconversionFailures() {
        return upconversionFailures;
    }
    
    public void setUpconversionFailures(List<UpConversionFailure> upconversionFailures) {
        this.upconversionFailures = upconversionFailures;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName()
            + "(source=" + source
            + ",rawPMathML=" + rawPMathML
            + ",pMathML=" + pMathML
            + ",cMathML=" + cMathML
            + ",maximaInput=" + maximaInput
            + ",upconversionFailures=" + upconversionFailures
            + ")";
    }
}
