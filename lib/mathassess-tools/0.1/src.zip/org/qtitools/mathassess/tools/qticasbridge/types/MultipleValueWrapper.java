/* $Id: MultipleValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

import java.util.AbstractSet;
import java.util.HashSet;

/**
 * Abstract base class for values with "multiple" cardinality, i.e. sets
 * 
 * @param <S> underlying {@link ValueWrapper} type of the {@link SingleValueWrapper} 
 *   for the elements in this Set
 * @param <B> underlying Java type of the elements in this Set
 * 
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public abstract class MultipleValueWrapper<B, S extends SingleValueWrapper<B>> 
        extends HashSet<S> implements CompoundValueWrapper<B,S> {
    
    private static final long serialVersionUID = -1943487267906694745L;
    
    public ValueCardinality getCardinality() {
        return ValueCardinality.MULTIPLE;
    }
    
    @Override
    public boolean add(S e) {
        ensureNotNull(e);
        return super.add(e);
    }
    
    public boolean isNull() {
        return false;
    }

    private void ensureNotNull(S e) {
        if (e==null) {
            throw new IllegalArgumentException(getClass().getSimpleName() + " must not contain null entries");
        }
    }

    /**
     * Overridden to change the semantics normally inherited from {@link AbstractSet} to
     * what we might expect here, which is that two such wrappers are the same if and only if
     * they have the same size and each element of this wrapper <strong>compares as equal</strong>
     * to an element in the other wrapper.
     */
    @Override
    public boolean equals(Object o) {
        if (o==this) {
            return true;
        }
        else if (!(o instanceof MultipleValueWrapper)) {
            return false;
        }
        MultipleValueWrapper<?,?> other = (MultipleValueWrapper<?,?>) o;
        if (size()!=other.size()) {
            return false;
        }
        /* FIXME: This algorithm is O(size^2), which is crap! */
        boolean foundThisInThat;
        for (S elementInThis : this) {
            foundThisInThat = false;
            for (Object elementInThat : other) {
                if (elementInThis.equals(elementInThat)) {
                    foundThisInThat = true;
                    break;
                }
            }
            if (!foundThisInThat) {
                return false;
            }
        }
        return true;
    }
}
