/* $Id: ValueOrVariableWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Simple marker interface representing a QTI <tt>expression</tt> that is either
 * <tt>baseValue</tt> or a <tt>variable</tt>. This is also the top of the Class
 * hierarchy defined in this package.
 * <p>
 * (This is clearly only a subset of the whole gamut of QTI expressions but is
 * sufficient for what is needed here.)
 * 
 * @see ValueWrapper
 * @see VariableWrapper
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public interface ValueOrVariableWrapper {
    
    /* (Nothing here) */

}
