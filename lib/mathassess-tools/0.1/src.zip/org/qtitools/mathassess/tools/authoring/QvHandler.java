/* $Id: QvHandler.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.authoring;

import uk.ac.ed.ph.snuggletex.dombuilding.CommandHandler;
import uk.ac.ed.ph.snuggletex.internal.DOMBuilder;
import uk.ac.ed.ph.snuggletex.internal.SnuggleParseException;
import uk.ac.ed.ph.snuggletex.tokens.CommandToken;

import org.w3c.dom.Element;

/**
 * SnuggleTeX DOM-building handler for the <tt>\\qv</tt> command.
 *
 * @author  FIXME
 * @version $Revision: 1902 $
 */
public final class QvHandler implements CommandHandler {
    
    public void handleCommand(DOMBuilder builder, Element parentElement, CommandToken token)
            throws SnuggleParseException {
        /* Get the name of the QTI variable */
        String variableIdentifier = builder.extractStringValue(token.getArguments()[0]);
        
        /* Now create a <mi ma:varIdentifier='name'/> element or <mi>name</mi> */
        if (AuthoringGlobals.ENCODE_PLACEHOLDER_AS_ATTRIBUTE) {
            Element miElement = builder.appendMathMLElement(parentElement, "mi");
            miElement.setAttributeNS(AuthoringGlobals.MATHASSESS_NS,
                    AuthoringGlobals.MATHASSESS_PREFIX + ":" + AuthoringGlobals.QV_ATTRIBUTE_NAME,
                    variableIdentifier);
        }
        else {
            builder.appendMathMLIdentifierElement(parentElement, variableIdentifier);
        }
    }
}
