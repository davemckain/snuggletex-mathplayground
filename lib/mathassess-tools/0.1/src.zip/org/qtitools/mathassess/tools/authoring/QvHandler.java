/* $Id: QvHandler.java 1955 2009-03-04 17:13:58Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.authoring;

import uk.ac.ed.ph.snuggletex.dombuilding.CommandHandler;
import uk.ac.ed.ph.snuggletex.internal.DOMBuilder;
import uk.ac.ed.ph.snuggletex.internal.SnuggleParseException;
import uk.ac.ed.ph.snuggletex.tokens.CommandToken;

import org.w3c.dom.Element;

/**
 * SnuggleTeX DOM-building handler for the <tt>\\qv</tt> command.
 *
 * @author  David McKain
 * @version $Revision: 1955 $
 */
public final class QvHandler implements CommandHandler {
    
    public void handleCommand(DOMBuilder builder, Element parentElement, CommandToken token)
            throws SnuggleParseException {
        /* Get the name of the QTI variable */
        String variableIdentifier = builder.extractStringValue(token.getArguments()[0]);
        
        /* Now create an <mi>variableIdentifier</mi> Element */
        builder.appendMathMLIdentifierElement(parentElement, variableIdentifier);
    }
}
