/* $Id: ExampleHelpers.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import uk.ac.ed.ph.snuggletex.DOMOutputOptions;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConvertingPostProcessor;

import java.io.IOException;

import org.qtitools.mathassess.tools.maxima.qticasbridge.BadQTICASCodeException;
import org.qtitools.mathassess.tools.maxima.qticasbridge.BridgeUtilities;
import org.qtitools.mathassess.tools.maxima.qticasbridge.MathsContentValueWrapper;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * A couple of silly helpers for the example classes.
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
final class ExampleHelpers {

    /**
     * Creates a {@link MathsContentValueWrapper} using SnuggleTeX for input, even though this
     * is never going to happen in reality. It's just that it's easier to do this from SnuggleTeX
     * rather than raw ASCIIMathML input!
     * 
     * @param asciiMathInput
     * @param cheatyLatex
     * @return
     * @throws BadQTICASCodeException 
     */
    public static MathsContentValueWrapper createMathsContentFromSnuggleTeX(final String asciiMathInput,
            final String cheatyLatex)
            throws BadQTICASCodeException {
        /* Use SnuggleTeX to convert to PMathML and do lots of fun up-conversions */
        SnuggleEngine engine = new SnuggleEngine();
        SnuggleSession session = engine.createSession();
        DOMOutputOptions outputOptions = new DOMOutputOptions();
        outputOptions.setDOMPostProcessor(new UpConvertingPostProcessor());
        try {
            session.parseInput(new SnuggleInput("$" + cheatyLatex + "$"));
        }
        catch (IOException e) {
            throw new BadQTICASCodeException("Bad SnuggleTeX input " + cheatyLatex+ " in example code!");
        }
        NodeList resultNodes = session.buildDOMSubtree(outputOptions);
        
        /* (Recall there's a fake root element in the result in case we build lots of Nodes.
         * In this case, we should only have built a single <math/> element so move up.
         */
        Element mathElement = (Element) resultNodes.item(0);
        Document mathDocument = mathElement.getOwnerDocument();
        mathDocument.replaceChild(mathElement, mathElement.getParentNode());
        
        /* Pull out all of the wreckage */
        MathsContentValueWrapper result = BridgeUtilities.unwrapUpconvertedMathMLDocument(mathDocument);
        
        /* Put the expected ASCIIMathInput into the result */
        result.setAsciiMathInput(asciiMathInput);
        
        /* That'is! */
        return result;
    }

}
