/* $Id: ExampleHelpers.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentOutputValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentSource;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.WrapperUtilities;

import uk.ac.ed.ph.snuggletex.DOMOutputOptions;
import uk.ac.ed.ph.snuggletex.SnuggleEngine;
import uk.ac.ed.ph.snuggletex.SnuggleInput;
import uk.ac.ed.ph.snuggletex.SnuggleSession;
import uk.ac.ed.ph.snuggletex.extensions.upconversion.UpConvertingPostProcessor;

import java.io.IOException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * A couple of silly helpers for the example classes.
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class ExampleHelpers {

    /**
     * Creates a {@link MathsContentValueWrapper} using SnuggleTeX for input, even though this
     * is never going to happen in reality. It's just that it's easier to do this from SnuggleTeX
     * rather than raw ASCIIMathML input!
     * @param cheatyLatex
     */
    public static MathsContentValueWrapper createFakeStudentRespose(final String cheatyLatex,
            final String asciiMathInput) {
        /* Use SnuggleTeX to convert to PMathML and do lots of fun up-conversions */
        SnuggleEngine engine = new SnuggleEngine();
        SnuggleSession session = engine.createSession();
        DOMOutputOptions outputOptions = new DOMOutputOptions();
        outputOptions.setDOMPostProcessor(new UpConvertingPostProcessor());
        try {
            session.parseInput(new SnuggleInput("$" + cheatyLatex + "$"));
        }
        catch (IOException e) {
            throw new IllegalArgumentException("Bad SnuggleTeX input " + cheatyLatex+ " in example code!");
        }
        NodeList resultNodes = session.buildDOMSubtree(outputOptions);
        
        /* (Recall there's a fake root element in the result in case we build lots of Nodes.
         * In this case, we should only have built a single <math/> element so move up.
         */
        Element mathElement = (Element) resultNodes.item(0);
        Document mathDocument = mathElement.getOwnerDocument();
        mathDocument.replaceChild(mathElement, mathElement.getParentNode());
        
        /* Pull out all of the wreckage */
        MathsContentOutputValueWrapper result = WrapperUtilities.createFromUpconvertedMathMLDocument(MathsContentSource.STUDENT_MATH_ENTRY_INTERACTION,
                mathDocument);
        result.setAsciiMathInput(asciiMathInput);
        
        /* That'is! */
        return result;
    }

}
