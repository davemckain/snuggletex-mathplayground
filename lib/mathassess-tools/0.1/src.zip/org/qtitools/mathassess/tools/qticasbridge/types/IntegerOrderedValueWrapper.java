/* $Id: IntegerOrderedValueWrapper.java 1912 2009-02-13 16:55:03Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Represents a value of cardinality 'ordered' having integer base type.
 *
 * @author  David McKain
 * @version $Revision: 1912 $
 */
public final class IntegerOrderedValueWrapper extends OrderedValueWrapper<Integer, IntegerValueWrapper> {

    private static final long serialVersionUID = 6084887627999436539L;

    public Class<IntegerValueWrapper> getItemClass() {
        return IntegerValueWrapper.class;
    }
}
