/* $Id: BooleanValueWrapper.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Wrapper representing a QTI boolean value.
 *
 * @author  David McKain
 * @version $Revision: 1902 $
 */
public final class BooleanValueWrapper implements ValueWrapper {
    
    private boolean value;
    
    public BooleanValueWrapper() {
        this(false);
    }
    
    public BooleanValueWrapper(final boolean value) {
        this.value = value;
    }
    
    public boolean getValue() {
        return value;
    }
    
    public void setValue(boolean value) {
        this.value = value;
    }

    public ValueType getType() {
        return ValueType.BOOLEAN;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" + value + ")";
    }
}
