/* $Id: IntegerValueWrapper.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Wrapper representing a QTI integer value.
 *
 * @author  David McKain
 * @version $Revision: 1902 $
 */
public final class IntegerValueWrapper implements ValueWrapper {
    
    private int value;
    
    public IntegerValueWrapper() {
        this(0);
    }
    
    public IntegerValueWrapper(final int value) {
        this.value = value;
    }
    
    public int getValue() {
        return value;
    }
    
    public void setValue(int value) {
        this.value = value;
    }

    public ValueType getType() {
        return ValueType.INTEGER;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" + value + ")";
    }
}
