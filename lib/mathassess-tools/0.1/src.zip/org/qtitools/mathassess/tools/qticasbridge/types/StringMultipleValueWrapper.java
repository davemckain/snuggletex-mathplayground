/* $Id: StringMultipleValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Represents a value of cardinality 'multiple' having string base type.
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class StringMultipleValueWrapper extends MultipleValueWrapper<String, StringValueWrapper> {

    private static final long serialVersionUID = 6084887627999436539L;
    
    public Class<StringValueWrapper> getItemClass() {
        return StringValueWrapper.class;
    }
}
