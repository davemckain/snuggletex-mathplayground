/* $Id: BooleanMultipleValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Represents a value of cardinality 'multiple' having boolean base type.
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class BooleanMultipleValueWrapper extends MultipleValueWrapper<Boolean, BooleanValueWrapper> {

    private static final long serialVersionUID = 6084887627999436539L;
    
    public Class<BooleanValueWrapper> getItemClass() {
        return BooleanValueWrapper.class;
    }
}
