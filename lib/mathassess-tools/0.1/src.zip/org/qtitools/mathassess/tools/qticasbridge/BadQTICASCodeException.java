/* $Id: BadQTICASCodeException.java 1955 2009-03-04 17:13:58Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge;

/**
 * Represents a failure caused by bad CAS code in the QTI, which should ultimately
 * be fixed by the QTI author.
 *
 * @author  David McKain
 * @version $Revision: 1955 $
 */
public final class BadQTICASCodeException extends QTICASAuthoringException {
    
    private static final long serialVersionUID = 5940754810506417594L;
    
    private final String maximaInput;

    public BadQTICASCodeException(final String maximaInput, final String message) {
        super(message);
        this.maximaInput = maximaInput;
    }

    public String getMaximaInput() {
        return maximaInput;
    }
}
