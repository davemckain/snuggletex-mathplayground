/* $Id: OrderedValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Abstract base class for values with "ordered" cardinality, i.e. lists.
 * 
 * @param <S> underlying {@link ValueWrapper} type of the {@link SingleValueWrapper} 
 *   for the elements in this List
 * @param <B> underlying Java type of the elements in this List
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public abstract class OrderedValueWrapper<B, S extends SingleValueWrapper<B>> 
        extends ArrayList<S> implements CompoundValueWrapper<B,S> {
    
    private static final long serialVersionUID = -1943487267906694745L;
    
    public ValueCardinality getCardinality() {
        return ValueCardinality.ORDERED;
    }
    
    @Override
    public boolean add(S e) {
        ensureNotNull(e);
        return super.add(e);
    }
    
    @Override
    public void add(int index, S e) {
        ensureNotNull(e);
        super.add(index, e);
    }
    
    @Override
    public boolean addAll(Collection<? extends S> c) {
        for (S e : c) {
            ensureNotNull(e);
        }
        return super.addAll(c);
    }
    
    @Override
    public boolean addAll(int index, Collection<? extends S> c) {
        for (S e : c) {
            ensureNotNull(e);
        }
        return super.addAll(index, c);
    }
    
    public boolean isNull() {
        return false;
    }
    
    private void ensureNotNull(S e) {
        if (e==null) {
            throw new IllegalArgumentException(getClass().getSimpleName() + " must not contain null entries");
        }
    }
}
