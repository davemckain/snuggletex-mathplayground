/* $Id: CompoundValueWrapper.java 1928 2009-02-18 11:36:01Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

import java.util.Collection;

/**
 * Abstract base class for "compound" types, i.e. QTI types with multiple or ordered cardinality.
 * 
 * @param <S> underlying {@link ValueWrapper} type of the {@link SingleValueWrapper} 
 *   for the elements in this Collection.
 * @param <B> underlying Java type of the elements in this collection
 *
 * @author  David McKain
 * @version $Revision: 1928 $
 */
public interface CompoundValueWrapper<B, S extends SingleValueWrapper<B>> 
        extends Collection<S>, ValueWrapper {
    
    /**
     * Returns the underlying class of the items in this {@link Collection}.
     * <p>
     * (This is slightly annoying, but is handy for instantiation purposes.)
     */
    Class<S> getItemClass();

}