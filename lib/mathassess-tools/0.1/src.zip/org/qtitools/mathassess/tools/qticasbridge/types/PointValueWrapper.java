/* $Id: PointValueWrapper.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper representing a QTI point value.
 * <p>
 * This one is slightly polymorphic in that it's essentially equivalent to an
 * {@link IntegerOrderedValueWrapper}, so we have methods here to convert to and from that form.
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class PointValueWrapper extends SingleValueWrapper<Integer[]> {
    
    public static final Integer[] ZERO_VALUE = new Integer[] { Integer.valueOf(0), Integer.valueOf(0) };
    
    public PointValueWrapper() {
        super(ZERO_VALUE);
    }
    
    public PointValueWrapper(final Integer[] value) {
        super(value);
    }
    
    public IntegerOrderedValueWrapper toIntegerOrderedValueWrapper() {
        return WrapperUtilities.createCompoundValue(IntegerOrderedValueWrapper.class,
                IntegerValueWrapper.class, getValue());
    }
    
    public void fromIntegerOrderedValueWrapper(IntegerOrderedValueWrapper valueWrapper) {
        setValue(valueWrapper.toArray(new Integer[valueWrapper.size()]));
    }
    
    @Override
    public ValueBaseType getBaseType() {
        return ValueBaseType.POINT;
    }
}
