/* $Id: FloatValueWrapper.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

/**
 * Wrapper representing a QTI float value.
 *
 * @author  David McKain
 * @version $Revision: 1902 $
 */
public final class FloatValueWrapper implements ValueWrapper {
    
    private float value;
    
    public FloatValueWrapper() {
        this(0.0f);
    }
    
    public FloatValueWrapper(final float value) {
        this.value = value;
    }
    
    public float getValue() {
        return value;
    }
    
    public void setValue(float value) {
        this.value = value;
    }

    public ValueType getType() {
        return ValueType.FLOAT;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" + value + ")";
    }
}
