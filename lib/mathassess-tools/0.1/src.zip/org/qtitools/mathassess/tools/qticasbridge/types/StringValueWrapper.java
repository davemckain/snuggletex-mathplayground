/* $Id: StringValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper representing a QTI string value.
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class StringValueWrapper extends SingleValueWrapper<String> {
    
    public StringValueWrapper() {
        super("");
    }
    
    public StringValueWrapper(final boolean value) {
        super(String.valueOf(value));
    }
    
    public StringValueWrapper(final String value) {
        super(value);
    }

    @Override
    public ValueBaseType getBaseType() {
        return ValueBaseType.STRING;
    }
}
