/* $Id: MAD02SRNoRand.java 1902 2009-02-10 16:44:34Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.qtitools.mathassess.tools.maxima.MaximaTimeoutException;
import org.qtitools.mathassess.tools.maxima.qticasbridge.BadQTICASCodeException;
import org.qtitools.mathassess.tools.maxima.qticasbridge.FloatValueWrapper;
import org.qtitools.mathassess.tools.maxima.qticasbridge.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.maxima.qticasbridge.QTIMaximaSession;
import org.qtitools.mathassess.tools.maxima.qticasbridge.ValueType;
import org.qtitools.mathassess.tools.maxima.qticasbridge.VariableWrapper;

/**
 * Demonstrates the QTI/Maxima bridge stuff by walking through what might happen when
 * processing the MAD02-SRNoRand.xml example.
 *
 * @author  David McKain
 * @version $Revision: 1902 $
 */
public final class MAD02SRNoRand {
    
    private static final Logger log = Logger.getLogger(MAD02SRNoRand.class);

    //------------------------------------------------
    // Usage demos (these will become tests shortly...!)
    
    public static void main(String[] args) throws MaximaTimeoutException, BadQTICASCodeException {
        QTIMaximaSession session = new QTIMaximaSession();
        session.open();
        try {
            /* Set correct response. (This would normally have been supplied by ASCIIMathML
             * but I'm going to cheat slightly here and build the result using SnuggleTeX to
             * save me having to input all of the various MathML snippets manually.)
             */
            MathsContentValueWrapper correctResponse = ExampleHelpers.createMathsContentFromSnuggleTeX("6x-10", "6x-10");
            log.info("Correct response is " + correctResponse);
            
            /* QTI then declares some strings and booleans. Not doing here as I've not added
             * support for them yet!
             */
            
            /* Now set the SCORE variable to 0.0f, as defined in the QTI */
            session.passQTIVariableToMaxima("SCORE", new FloatValueWrapper(0.0f));
            
            /* QTI then declares mAns, mBad1 etc. There's actually nothing to do here as they're
             * going to be set via ScriptRule
             */
            
            /* Now do ScriptRule to set the variables listed above. */
            session.executeScriptRule("mAns:6*x-10;"
                    + "mBad1:-10+6*x;"
                    + "mBad2:2*x-10+4*x;"
                    + "mBad3:6*x-5;"
                    + "mBad4:5*x-10;"
                    + "mBad5:6*x+10;"
                    + "mBad6:2*(3*x-5);"
                    + "mBad7:2*(x-5)+4*x;");
            
            /* Next up, we'd extract the values of these and store them as Math variables */
            Map<String, MathsContentValueWrapper> mathVariableValueMap = new HashMap<String, MathsContentValueWrapper>();
            for (String variableName : new String[] { "mAns", "mBad1", "mBad2", "mBad3", "mBad4", "mBad5", "mBad6", "mBad7" }) {
                MathsContentValueWrapper mathsContentValue = (MathsContentValueWrapper) session.queryVariable(variableName, ValueType.MATHS_CONTENT);
                log.info("Extracted math variable " + variableName + " having value " + mathsContentValue);
                mathVariableValueMap.put(variableName, mathsContentValue);
                
                /* NOTE: Some of these are currently wrong due to the up-conversion not
                 * working fully yet!
                 */
            }
            
            /* Next would be rendering. In this example, there are no substitutions of any of the
             * above variables so it's all plain sailing here...
             */
            
            /* OK, now let's suppose the student input was equivalent to mBad1.
             * (I'm going to cheat as above and build the resulting mathsContext from SnuggleTeX).
             */
            MathsContentValueWrapper studentResponse = ExampleHelpers.createMathsContentFromSnuggleTeX("-10+6x", "-10+6x");
            session.passQTIVariableToMaxima("RESPONSE", studentResponse);
            log.info("Student response is " + studentResponse);
            
            /* Now we do the response processing.
             * First relevant thing here is the CasCompare with the correct response, which should
             * yield false
             */
            boolean comparisonResult = session.executeCasCompare(QTIMaximaSession.MAXIMA_SYNTEQUAL_CODE,
                    new VariableWrapper("RESPONSE"), correctResponse);
            log.info("Comparison with correct response yielded " + comparisonResult);
            if (comparisonResult==true) {
                log.error("Got wrong result in this comparison!");
            }
            
            /* Next we'd compare with mBad1, which ought to return true */
            comparisonResult = session.executeCasCompare(QTIMaximaSession.MAXIMA_SYNTEQUAL_CODE,
                    new VariableWrapper("RESPONSE"), new VariableWrapper("mBad1"));
            log.info("Comparison with mBad1 response yielded " + comparisonResult);
            if (comparisonResult==false) {
                log.error("Got wrong result in this comparison!");
            }
            
            /* Yay, hopefully! */
            
            /* And that's about it for this particular example! */
        }
        finally {
            session.close();
        }
    }
}
