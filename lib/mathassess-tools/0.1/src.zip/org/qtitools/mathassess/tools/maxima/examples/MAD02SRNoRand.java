/* $Id: MAD02SRNoRand.java 1976 2009-03-10 14:29:22Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.examples;

import org.qtitools.mathassess.tools.qticasbridge.maxima.QTIMaximaSession;
import org.qtitools.mathassess.tools.qticasbridge.types.FloatValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.MathsContentValueWrapper;
import org.qtitools.mathassess.tools.qticasbridge.types.VariableWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * Demonstrates the QTI/Maxima bridge stuff by walking through what might happen when
 * processing the MAD02-SRNoRand.xml example.
 *
 * @author  David McKain
 * @version $Revision: 1976 $
 */
public final class MAD02SRNoRand {
    
    public static void main(String[] args) throws Exception {
        QTIMaximaSession session = new QTIMaximaSession();
        session.open();
        try {
            /* Create a MathsContentValueWrapper for the "correct response" value.
             * 
             * This directly mirrors what is authored in the QTI XML.
             * 
             * Note that the QTI/CAS bridge code is interested in the Content MathML field
             * so there's no need to fill it in.
             */
            MathsContentValueWrapper correctResponse = new MathsContentValueWrapper();
            correctResponse.setPMathML("<math xmlns=\"http://www.w3.org/1998/Math/MathML\">\n" + 
            		"  <semantics>\n" + 
            		"    <mrow>\n" + 
            		"      <mrow>\n" + 
            		"        <mn>6</mn>\n" + 
            		"        <mo>&#8290;</mo>\n" + 
            		"        <mi>x</mi>\n" + 
            		"      </mrow>\n" + 
            		"      <mo>-</mo>\n" + 
            		"      <mn>10</mn>\n" + 
            		"    </mrow>\n" + 
            		"  </semantics>\n" + 
            		"</math>");
            correctResponse.setCMathML("<blah/>"); /* (You'd normally fill this in correctly, though it isn't actually used anywhere!) */
            correctResponse.setMaximaInput("((6*x)-10)");
            
            System.out.println("Correct response is " + correctResponse);
            
            /* QTI then declares some strings and booleans. Not doing here as I've not added
             * support for them yet!
             */
            
            /* Now set the SCORE variable to 0.0f, as defined in the QTI */
            session.passQTIVariableToMaxima("SCORE", new FloatValueWrapper(0.0));
            
            /* QTI then declares mAns, mBad1 etc. There's actually nothing to do here as they're
             * going to be set via ScriptRule
             */
            
            /* Now do ScriptRule to set the variables listed above. */
            session.executeScriptRule("mAns:6*x-10;"
                    + "mBad1:-10+6*x;"
                    + "mBad2:2*x-10+4*x;"
                    + "mBad3:6*x-5;"
                    + "mBad4:5*x-10;"
                    + "mBad5:6*x+10;"
                    + "mBad6:2*(3*x-5);"
                    + "mBad7:2*(x-5)+4*x;");
            
            /* Next up, we'd extract the values of these and store them as Math variables */
            Map<String, MathsContentValueWrapper> mathVariableValueMap = new HashMap<String, MathsContentValueWrapper>();
            for (String variableName : new String[] { "mAns", "mBad1", "mBad2", "mBad3", "mBad4", "mBad5", "mBad6", "mBad7" }) {
                MathsContentValueWrapper mathsContentValue = session.queryMaximaVariable(variableName, MathsContentValueWrapper.class);
                System.out.println("Extracted math variable " + variableName + " having value " + mathsContentValue);
                mathVariableValueMap.put(variableName, mathsContentValue);
                
                /* NOTE: Some of these are currently wrong due to the up-conversion not
                 * working fully yet!
                 */
            }
            
            /* Next would be rendering. In this example, there are no substitutions of any of the
             * above variables so it's all plain sailing here...
             */
            
            /* OK, now let's suppose the student input was equivalent to mBad1.
             * (I'm going to cheat as above and build the resulting mathsContext from SnuggleTeX).
             */
            MathsContentValueWrapper studentResponse = ExampleHelpers.createFakeStudentRespose("-10+6x", "-10+6x");
            session.passQTIVariableToMaxima("RESPONSE", studentResponse);
            System.out.println("Student response is " + studentResponse);
            
            /* Now we do the response processing.
             * First relevant thing here is the CasCompare with the correct response, which should
             * yield false
             */
            boolean comparisonResult = session.executeCasCompare(QTIMaximaSession.MAXIMA_SYNTEQUAL_CODE, false,
                    new VariableWrapper("RESPONSE"), correctResponse);
            System.out.println("Comparison with correct response yielded " + comparisonResult);
            if (comparisonResult==true) {
                System.out.println("Got wrong result in this comparison!");
            }
            
            /* Next we'd compare with mBad1, which ought to return true */
            comparisonResult = session.executeCasCompare(QTIMaximaSession.MAXIMA_SYNTEQUAL_CODE, false,
                    new VariableWrapper("RESPONSE"), new VariableWrapper("mBad1"));
            System.out.println("Comparison with mBad1 response yielded " + comparisonResult);
            if (comparisonResult==false) {
                System.out.println("Got wrong result in this comparison!");
            }
            
            /* Yay, hopefully! */
            
            /* And that's about it for this particular example! */
        }
        finally {
            session.close();
        }
    }
}
