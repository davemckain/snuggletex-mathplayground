/* $Id: IntegerValueWrapper.java 1918 2009-02-16 15:02:55Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.qticasbridge.types;

/**
 * Wrapper representing a QTI integer value.
 *
 * @author  David McKain
 * @version $Revision: 1918 $
 */
public final class IntegerValueWrapper extends SingleValueWrapper<Integer> {
    
    public IntegerValueWrapper() {
        super(Integer.valueOf(0));
    }
    
    public IntegerValueWrapper(final Integer value) {
        super(value);
    }
    
    public IntegerValueWrapper(final int value) {
        super(Integer.valueOf(value));
    }
    
    @Override
    public ValueBaseType getBaseType() {
        return ValueBaseType.INTEGER;
    }
}
