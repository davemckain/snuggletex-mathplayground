/* $Id: BridgeUtilities.java 1901 2009-02-10 14:20:52Z davemckain $
 *
 * Copyright 2009 University of Edinburgh.
 * All Rights Reserved
 */
package org.qtitools.mathassess.tools.maxima.qticasbridge;

import uk.ac.ed.ph.snuggletex.extensions.upconversion.MathMLUpConverter;
import uk.ac.ed.ph.snuggletex.utilities.MathMLUtilities;
import uk.ac.ed.ph.snuggletex.utilities.UnwrappedParallelMathMLDOM;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Some slightly random utility methods that I've moved out of {@link QTIMaximaSession} as
 * they don't require a running Maxima session.
 * <p>
 * Might be useful... but probably not!
 *
 * @author  David McKain
 * @version $Revision: 1901 $
 */
public final class BridgeUtilities {
    
    /**
     * Unravels an up-converted MathML document (as produced previously from either from raw
     * SnuggleTeX, ASCIIMathML or Maxima MathML output) and converts the result to a
     * {@link MathsContentValueWrapper}.
     * <p>
     * The caller should have checked that there were no errors in the process.
     * 
     * @param mathMLDocument
     */
    public static MathsContentValueWrapper unwrapUpconvertedMathMLDocument(final Document mathMLDocument) {
        return unwrapUpconvertedMathMLDocument(MathMLUtilities.unwrapParallelMathMLDOM(mathMLDocument.getDocumentElement()));
    }
    
    /**
     * Unravels an up-converted MathML document (as produced previously from either from raw
     * SnuggleTeX, ASCIIMathML or Maxima MathML output) and converts the result to a
     * {@link MathsContentValueWrapper}.
     * <p>
     * The caller should have checked that there were no errors in the process.
     */
    public static MathsContentValueWrapper unwrapUpconvertedMathMLDocument(final UnwrappedParallelMathMLDOM unwrappedDocument) {
        /* Pull out the relevant bits from the wreckage */
        MathsContentValueWrapper result = new MathsContentValueWrapper();
        result.setMaximaInput(unwrappedDocument.getTextAnnotations().get(MathMLUpConverter.MAXIMA_ANNOTATION_NAME));
        result.setAsciiMathInput(unwrappedDocument.getTextAnnotations().get(MathMLUpConverter.ASCIIMATH_INPUT_ANNOTATION_NAME));
        result.setPMathMLElement(unwrappedDocument.getFirstBranch());
        
        /* CMathML is returned as a NodeList but should in all cases contain a single Element */
        NodeList cmathMLList = unwrappedDocument.getXmlAnnotaions().get(MathMLUpConverter.CONTENT_MATHML_ANNOTATION_NAME);
        if (cmathMLList.getLength()!=1 && cmathMLList.item(0).getNodeType()!=Node.ELEMENT_NODE) {
            throw new QTICASBridgeException("Expected Content MathML annotation to consist of a single Element");
        }
        result.setCMathMLElement((Element) cmathMLList.item(0));
        
        /* That's it! */
        return result;
    }
}
